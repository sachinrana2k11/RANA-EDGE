import { SafeAreaProvider } from "react-native-safe-area-context";
import { NativeRouter } from "react-router-native";
import Index from "./Index";
export default function App() {
  return (
    <SafeAreaProvider>
      <NativeRouter>
        <Index />
      </NativeRouter>
    </SafeAreaProvider>
  );
}
