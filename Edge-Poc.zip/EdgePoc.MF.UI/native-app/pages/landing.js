import { StyleSheet, View, TouchableOpacity, Alert, Pressable } from "react-native";
import { Header } from "@rneui/themed";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { useNavigate } from "react-router-native";
import { StatusBar } from "expo-status-bar";
import { Text, Card, Button, Icon } from "@rneui/themed";
import { useEffect, useState, useContext } from "react";
import { PieChart } from "react-native-chart-kit";
export default function Landing() {
    const navigate = useNavigate();
    const [homeData, setHomeData] = useState({
        "activeAsset": 0,
        "offlineAsset": 0,
        "onboardedAsset": 0,
        "totalCriticalAlerts": 0,
        "totalWarningAlerts": 0
    })
    var data = [
        {
            name: "Warning",
            population: homeData.totalWarningAlerts,
            color: "#FFE600",
            legendFontColor: "black",
            legendFontSize: 15
        },
        {
            name: "Critical",
            population: homeData.totalCriticalAlerts,
            color: "red",
            legendFontColor: "black",
            legendFontSize: 15
        },

    ];

    const chartConfig = {
        color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
    };

    const handlePath = (path) => {
        navigate({
            pathname: `/${path}`,
        });
    };

    const logoutConfirmation = () =>
        Alert.alert('Logout', 'Are you sure you want to logout', [
            {
                text: 'Cancel',
                style: 'cancel',
            },
            { text: 'Logout', onPress: () => handlePath("login") },
        ]);


    useEffect(() => {
        let api_url = 'http://10.1.45.71:3002/deviceService/v1/index';
        fetch(api_url)
            .then(res => {
                if (res.status >= 400) {
                    throw new Error("Server responds with error!");
                }
                return res.json();
            })
            .then(users => {
                setHomeData(users)
            },
                err => {
                    setHomeData([{ Critical: "0", Warning: "0" }])
                    console.log("Home Api Err", err);
                });
    }, [])

    var av = `<iframe src="http://10.1.45.71:3000/d-solo/Zdnyae24z/landing?orgId=1&from=1675921417231&to=1675943017232&panelId=4" width="450" height="200" frameborder="0"></iframe>`
    return (<>
        <SafeAreaProvider>
            <View style={styles.container}>
                <Header
                    leftComponent={{
                        icon: "chevron-left", color: "#fff",
                        onPress: logoutConfirmation
                    }}
                    centerComponent={{
                        text: "Plant Overview",
                        style: { color: "#fff", fontSize: 17 },
                    }}
                    rightComponent={<View style={styles.headerRight}>
                        <TouchableOpacity
                            style={{ marginRight: 15 }}
                        >
                            <Icon type="feather" name="clock" color="white" />
                        </TouchableOpacity>
                    </View>
                    }

                    // rightComponent={{ icon: "home", color: "#fff" }}
                    containerStyle={{
                        backgroundColor: "#2e2e38",
                        justifyContent: "space-around",
                    }}
                />
                <View style={[styles.row]}>
                    <Card containerStyle={{ width: 180, alignItems: "center" }}>
                        <View style={styles.row}>
                            <Icon type="font-awesome" size={50} name="plug" color="green" />
                            <Text style={{ color: "green", marginTop: 0, fontSize: 40 }}>
                                {homeData.onboardedAsset}
                            </Text>
                        </View><Text style={{ marginTop: 5, fontSize: 15 }}>
                            Onboarded Asset
                        </Text>
                    </Card>
                    <Card containerStyle={{ width: 180, alignItems: "center" }}>
                        <View style={styles.row}>
                            <Icon type="font-awesome" size={50} name="signal" color="green" />
                            <Text style={{ color: "green", marginLeft: 10, fontSize: 40 }}>
                                {homeData.activeAsset}
                            </Text>
                        </View>
                        <Text style={{ marginTop: 5, fontSize: 15 }}>
                            Active Asset
                        </Text>
                    </Card>
                </View>

                <View style={[styles.row]}>
                    <Card containerStyle={{ width: 180, alignItems: "center" }}>
                        <View style={[styles.row,]}>
                            <Icon size={50} type="ion-icons" name="cloud-off" color="green" />
                            {homeData.offlineAsset > 0 && <Text style={{ color: "red", marginTop: 0, fontSize: 40 }}>
                                {homeData.offlineAsset}
                            </Text>
                            }
                            {homeData.offlineAsset == 0 && <Text style={{ color: "green", marginTop: 0, fontSize: 40 }}>
                                {homeData.offlineAsset}
                            </Text>
                            }

                        </View><Text style={{ marginTop: 5, fontSize: 15 }}>
                            Offline Asset
                        </Text>
                    </Card>

                    <Card containerStyle={{ width: 180, alignItems: "center" }}>
                        <View style={styles.row}>
                            <Icon type="ion-icons" size={50} name="notifications" color="red" />
                            <Text style={{ color: "red", marginLeft: 10, fontSize: 40 }}>
                                {homeData.totalCriticalAlerts + homeData.totalWarningAlerts}
                            </Text>
                        </View>
                        <Text style={{ marginTop: 5, fontSize: 15 }}>
                            Active Alerts
                        </Text>
                    </Card>
                </View>
                <View style={[styles.row]}>
                    <PieChart
                        data={data}
                        width={400}
                        height={220}
                        chartConfig={chartConfig}
                        accessor={"population"}
                        backgroundColor={"transparent"}
                        paddingLeft={"10"}
                        center={[10, -10]}
                        style={{ margin: 20 }}
                    />
                </View>
                <View style={[styles.row]}>

                    <Button
                        onPress={() => { handlePath("home") }}
                        buttonStyle={{
                            width: 150,
                            borderRadius: 0,
                            marginLeft: 0,
                            marginRight: 10,
                            marginBottom: 0,
                            padding: 5,
                            backgroundColor: "#4c4c54",
                        }}
                        title={"View Assets"}
                    />
                </View>
                <StatusBar style="auto" />
            </View>
        </SafeAreaProvider>
    </>
    );
}

const styles = StyleSheet.create({
    container: {},
    row: {
        flexDirection: "row",
        justifyContent: "space-around"
    },

});
