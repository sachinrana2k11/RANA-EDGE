import { StyleSheet, View, TouchableOpacity, Alert, ScrollView } from "react-native";
import { Header } from "@rneui/themed";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { useNavigate, Route, Routes } from "react-router-native";
import { StatusBar } from "expo-status-bar";
import { Text, Card, Button, Icon } from "@rneui/themed";
import { useEffect, useState } from "react";
export default function Home() {
  const navigate = useNavigate();

  const handlePath = (path, device) => {
    navigate({
      pathname: `/${path}`,
      search: `assetName=${device}`
    });
  };

  const [devices, setDevices] = useState([])

  useEffect(() => {
    let api_url = 'http://10.1.45.71:3002/deviceService/v1/alertCount';
    fetch(api_url)
      .then(res => {
        if (res.status >= 400) {
          throw new Error("Server responds with error!");
        }
        return res.json();
      })
      .then(users => {
        setDevices(users)
      },
        err => {
          setDevices([{ Critical: "0", Warning: "0" }])
          console.log("Home Api Err", err);
        });
  }, [])


  return (
    <SafeAreaProvider>
      <View style={styles.container}>
        <Header
          leftComponent={{
            icon: "chevron-left", color: "#fff",
            onPress: () => handlePath("landing")
          }} centerComponent={{
            text: "Device List",
            style: { color: "#fff", fontSize: 17 },
          }}
          rightComponent={<View style={styles.headerRight}>
            <TouchableOpacity
              onPress={() => handlePath("landing")}
              style={{ marginRight: 15 }}
            >
              <Icon name="home" color="white" />
            </TouchableOpacity>
          </View>
          }
          containerStyle={{
            backgroundColor: "#2e2e38",
            justifyContent: "space-around",
          }}
        />
        <ScrollView style={styles.scrollView}>

          {devices.map((el, idx) => {
            return (<Card key={idx}>
              <Card.Title>{el.AssetName}</Card.Title>
              <Card.Divider />
              {el.AssetName == "MotorA" && <Card.Image
                style={{ padding: 0 }}
                source={require("../assets/motor.jpeg")}
              />}
              {el.AssetName == "ID_Fan" && <Card.Image
                style={{ padding: 0 }}
                source={require("../assets/idfan.jpeg")}
              />}
              {el.AssetName == "Motor_ConveyorBelt" && <Card.Image
                style={{ padding: 0 }}
                source={require("../assets/conveyorbelt.jpg")}
              />}
              {el.AssetName == "Oil_Lubrication_Pump" && <Card.Image
                style={{ padding: 0 }}
                source={require("../assets/lub_pump.jpg")}
              />}
              <Text style={{ marginBottom: 5, marginTop: 5 }}>
                Organization Name: EY India
              </Text>
              <Text style={{ marginBottom: 5 }}>Critical Alerts: {el.Critical}</Text>
              <Text style={{ marginBottom: 10 }}>Warning Alerts: {el.Warning}</Text>
              <Button
                onPress={() => {
                  handlePath("chat", el.AssetName);
                }}
                icon={
                  <Icon
                    name="cloud-off"
                    color="#ffffff"
                    iconStyle={{ marginRight: 10 }}
                  />
                }
                buttonStyle={{
                  borderRadius: 0,
                  marginLeft: 0,
                  marginRight: 0,
                  marginBottom: 0,
                  padding: 5,
                  backgroundColor: "#4c4c54",
                }}
                title="View Details"
              />
            </Card>
            )
          })}
        </ScrollView>
        <StatusBar style="auto" />
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {},
  scrollView: { backgroundColor: "whitesmoke" },

});
