import { StyleSheet, ScrollView, View, TouchableOpacity, Dimensions } from "react-native";
import { Header } from "@rneui/themed";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { useNavigate } from "react-router-native";
import { StatusBar } from "expo-status-bar";
import { Text, Card, CheckBox, BottomSheet, Button, Icon, Badge, Overlay, ListItem } from "@rneui/themed";
import { useState, useEffect } from "react";
import AlertData from "./modals/AlertDetails";
import FilterModal from "./modals/FilterModal";
import Loader from "./modals/Loader";
import AckModal from "./modals/AckModal";
import { useLocation } from "react-router-native";
import FilterParams from "./modals/FilterParams";
const vw = Dimensions.get("window").width;
export default function AlertList() {
  const navigate = useNavigate();
  let { search } = useLocation()
  console.log("this is state", search.slice(11));
  const dateConvert = (time) => {
    let date = new Date(time)
    return date.toLocaleString()
  }
  const handlePath = (path) => {
    navigate({
      pathname: `/${path}`,
    });
  };
  var defInterval = 3600
  const [checkedCritical, setCheckedCritical] = useState(true);
  const toggleCheckboxCritical = () => setCheckedCritical(!checkedCritical);
  const [checkedWarning, setCheckedWarning] = useState(true);
  const toggleCheckboxWarning = () => setCheckedWarning(!checkedWarning);
  const [selectedRadio, setSelectedRadio] = useState(7)
  const [bottomSheetVisible, setBottomSheetVisible] = useState(false);

  const bottomSheetSubmit = () => {
    setBottomSheetVisible(false)
    setLoading(true)
    defInterval = list[selectedRadio].time
    let start = Math.floor(Date.now() / 1000) - list[selectedRadio].time
    let stop = Math.floor(Date.now() / 1000)
    let atemptype = null
    setStartTime(start)
    setStopTime(stop)
    if (checkedCritical && !checkedWarning) {
      setAType("Critical")
      atemptype = "Critical"
    }
    if (!checkedCritical && checkedWarning) {
      setAType("Warning")
      atemptype = "Warning"
    }

    let url = `http://10.1.45.71:3002/deviceService/v1/alertList?asset=${search.slice(11)}&start=` + `${start}` + "&stop=" + `${stop}`;
    atemptype ? url += `&atype=${atemptype}` : null
    getAlertList(url)
  }

  const [loading, setLoading] = useState(false)
  const [alertDetailsVisible, setAlertDetailsVisible] = useState(false);
  const handleAlertModal = (data, close, ack) => {
    setAlertData(data)
    close ? setAlertDetailsVisible(false) : setAlertDetailsVisible(true);
    ack ? handleAckModal(data) : null
  };

  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const handleFilterModal = (close) => {
    close ? setFilterModalVisible(false) : setFilterModalVisible(true);
  };

  const [ackModalVisible, setAckModalVisible] = useState(false);
  const handleAckModal = (data, close, newdata) => {
    setAlertData(data)
    if (newdata) {
      let temp = [...allAlerts]
      data.AlertAck = 1
      let idx = temp.findIndex(a => a.msgid == data.msgid)
      if (idx != -1) {
        temp.splice(idx, 1, data)
        setAllAlerts(temp)
      }
    }
    close ? setAckModalVisible(false) : setAckModalVisible(true);
  };


  const [allAlerts, setAllAlerts] = useState([])
  const [displayAlerts, setDisplayAlerts] = useState([])




  const [alertData, setAlertData] = useState(allAlerts[0])
  const [startTime, setStartTime] = useState(Math.floor(Date.now() / 1000) - list[selectedRadio].time)
  const [stopTime, setStopTime] = useState(Math.floor(Date.now() / 1000))

  const [aType, setAType] = useState(null)
  useEffect(() => {

    // var interval = setInterval(() => {
    //   getDefaultData()
    // }, 60000);
    getAlertList()
    // return (() => {
    //    clearInterval(interval)
    // })
  }, [])

  function getDefaultData() {
    setStartTime(Math.floor(Date.now() / 1000))
    setStopTime(Math.floor(Date.now() / 1000) - defInterval)
    getAlertList()
  }
  function getAlertList(url) {
    let api_url = ""
    // ?asset=MotorA&start=1676602249&stop=1676608849&atype=Warning
    if (!url) {
      let str = `http://10.1.45.71:3002/deviceService/v1/alertList?asset=${search.slice(11)}&start=`
      api_url = str + `${startTime}` + "&stop=" + `${stopTime}`;
    } else { api_url = url }
    console.log(api_url);
    setLoading(true)
    const requestOptions = {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    };

    fetch(api_url, requestOptions)
      .then(res => {
        if (res.status >= 400) {
          throw new Error("Server responds with error!");
        }
        return res.json();
      })
      .then(alrt => {
        setAllAlerts(alrt)
        console.log(alrt[0] ? alrt[0] : "Sheh");
        setLoading(false)
      },
        err => {
          console.log("This is err", err);
          setLoading(false)
        });
  }


  return (
    <SafeAreaProvider>
      <View style={styles.container}>
        <Loader loading={loading} />
        <Header
          leftComponent={
            <View style={styles.headerRight}>
              <TouchableOpacity
                onPress={() => handlePath("home")}
                style={{ marginLeft: 15 }}
              >
                <Icon type="feather" name="chevron-left" color="white" />
              </TouchableOpacity>
            </View>
          }
          centerComponent={
            <View style={styles.headerRight}>
              <Text style={{ color: "white" }}>ALERTS ({list[selectedRadio].title.slice(5)})</Text>
            </View>

          }
          rightComponent={<View style={styles.headerRight}>
            {/* <TouchableOpacity
              onPress={() => handleFilterModal()}
              style={{ marginRight: 15 }}
            >
              <Icon type="feather" name="filter" color="white" />
            </TouchableOpacity> */}

            <TouchableOpacity

              style={{ marginRight: 10 }}
            >
              <Icon type="feather" name="filter" color="white" />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setBottomSheetVisible(true)}
              style={{ marginLeft: 15 }}
            >
              <Icon type="feather" name="clock" color="white" />
            </TouchableOpacity>

          </View>
          }

          containerStyle={{
            backgroundColor: "#2e2e38",
            justifyContent: "space-around",
          }}
        />
        <ScrollView style={styles.scrollView}>
          {allAlerts.length == 0 ?
            <Text style={[styles.defWidth]}>No data to show</Text> : null}
          {allAlerts.map((el, idx) => {
            return (
              <Card key={idx} containerStyle={styles.cardContainer}>
                <View
                  style={[
                    styles.rowStyle,
                    { justifyContent: "space-between", marginTop: 5 },
                  ]}
                >
                  <Text>Type</Text>
                  <View style={[
                    styles.rowStyle,
                    { justifyContent: "space-between", marginTop: 5 },
                  ]}
                  >
                    {el.AlertAckComment == "Resolve:- Asset is running healthy"
                      && <Badge
                        badgeStyle={{ height: 20 }}
                        textStyle={{ color: "white" }}
                        value="Resolved"
                        status="success"
                        containerStyle={{ marginRight: 10 }}
                      />}

                    <Badge
                      badgeStyle={{ height: 20 }}
                      textStyle={{ color: "white" }}
                      value={el.Logic}
                      status={el.Logic == "Critical" ? "error" : "warning"}
                    />

                  </View>


                </View>
                <View
                  style={[
                    styles.rowStyle,
                    { justifyContent: "space-between", marginTop: 5 },
                  ]}
                >
                  <Text style={styles.capitalize}>{
                    el.AlertProperty.slice(
                      el.AlertProperty.split(".", 2).join(".").length + 1
                    )


                  }</Text>
                  <Text>{el.AlertPropertyValue.toFixed(0)}</Text>
                </View>

                <View
                  style={[
                    styles.rowStyle,
                    { justifyContent: "space-between", marginTop: 5 },
                  ]}
                >
                  <Text>Date</Text>
                  <Text>{dateConvert(el.AlertGenTime)}</Text>
                </View>

                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "flex-end",
                    marginTop: 5,
                  }}
                >
                  {el.AlertAckComment != "Resolve:- Asset is running healthy" && <Button
                    onPress={() => { handleAckModal(el); }}
                    buttonStyle={{
                      minwidth: 120,
                      borderRadius: 0,
                      marginLeft: 0,
                      marginRight: 10,
                      marginBottom: 0,
                      padding: 5,
                      backgroundColor: "#4c4c54",
                    }}
                    title={el.AlertAck == 0 ? "Acknowledge" : "Update Status"}
                  />}


                  <Button
                    onPress={() => {
                      handleAlertModal(el);
                    }}
                    buttonStyle={{
                      width: 110,
                      borderRadius: 0,
                      marginLeft: 0,
                      marginRight: 0,
                      marginBottom: 0,
                      padding: 5,
                      backgroundColor: "#4c4c54",
                    }}
                    title="View Details"
                  />
                </View>
              </Card>
            );
          })}
          <Overlay isVisible={alertDetailsVisible}>
            <AlertData alertData={alertData} handleAlertModal={handleAlertModal} />
          </Overlay>

          <Overlay isVisible={filterModalVisible}>
            <FilterModal handleFilterModal={handleFilterModal} />
          </Overlay>
          <Overlay isVisible={ackModalVisible}>
            <AckModal alertData={alertData} handleAckModal={handleAckModal} />
          </Overlay>
        </ScrollView>

        <BottomSheet modalProps={{}} isVisible={bottomSheetVisible}>
          <ScrollView style={[styles.scrollView1, {}]}>
            {list.map((l, i) => (
              <ListItem
                key={i}
                containerStyle={l.containerStyle}
              >
                <ListItem.Content style={{ flexDirection: "row", justifyContent: "space-between", margin: -20, }}>
                  <CheckBox
                    checked={selectedRadio === i}
                    onPress={() => setSelectedRadio(i)}
                    checkedIcon="dot-circle-o"
                    uncheckedIcon="circle-o"
                    title={l.title}
                    style={{ margin: 0, padding: 0 }}
                  />
                </ListItem.Content>
              </ListItem>
            ))}</ScrollView>

          <View style={[{ flexDirection: "row", justifyContent: "flex-start", backgroundColor: "white" }]}>
            <CheckBox
              checked={checkedCritical}
              onPress={toggleCheckboxCritical}
              title="Critical"
            />
            <CheckBox
              checked={checkedWarning}
              onPress={toggleCheckboxWarning}
              title="Warning"
            />
          </View>
          <View
            style={[{
              flexDirection: "row", backgroundColor: "white", justifyContent: "center",
              marginBottom: 0,
              paddingBottom: 10
            }]}
          >
            <Button
              onPress={() => {
                setBottomSheetVisible(false);
              }}
              buttonStyle={{
                width: 120,
                padding: 5,
                marginLeft: 10,
                backgroundColor: "grey",
              }}
              title="Cancel"
              titleStyle={{ color: "white" }}
            />
            <Button
              onPress={() => {
                bottomSheetSubmit();
              }}
              buttonStyle={{
                width: 120,
                padding: 5,
                marginLeft: 10,
                backgroundColor: "#FFE600",
              }}
              title="Submit"
              titleStyle={{ color: "#2e2e38" }}
            />
          </View>

        </BottomSheet>
        <StatusBar style="auto" />
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {},
  defWidth: { textAlign: "center", fontSize: 20, marginTop: 60 },
  capitalize: {
    textTransform: "capitalize"
  },
  headerRight: {
    display: "flex",
    flexDirection: "row",
    marginTop: 5,
  },
  scrollView: { backgroundColor: "whitesmoke" },
  scrollView1: { maxHeight: 300 },
  cardContainer: { backgroundColor: "#fff", borderRadius: 10 },
  rowStyle: {
    flexDirection: "row",
    marginBottom: 5,
  },
});
const list = [
  { title: 'Last 5 min', time: "300" },
  { title: 'Last 15 min', time: "900" },
  { title: 'Last 30 min', time: "1800" },
  { title: 'Last 1 hour', time: "3600" },
  { title: 'Last 3 hour', time: "10800" },
  { title: 'Last 6 hour', time: "21600" },
  { title: 'Last 12 hour', time: "43200" },
  { title: 'Last 24 hour', time: "86400" },
  { title: 'Last 2 day', time: "172800" },
  { title: 'Last 7 day', time: "604800" },
  { title: 'Last 30 day', time: "2592000" },
  { title: 'Last 90 day', time: "7776000" },
  { title: 'Last 6 months', time: "15780000" },
  { title: 'Last 1 year', time: "31536000" },
]





