import {
  StyleSheet,
  View,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
  Dimensions,
  TouchableOpacity,
} from "react-native";
import { Table, Row, } from "react-native-table-component";
import { Icon, Header, Button } from "@rneui/themed";
import { useEffect, useState } from "react";

const vh = Dimensions.get("window").height;
const vw = Dimensions.get("window").width;

const AlertData = (props) => {
  const { alertData } = props
  const data = Object.entries(alertData)
  const tableHead = ["Property", "Value"];

  useEffect(() => {
    let temp = [["Device", "Motor_A"]]
    for (let i = 0; i < data.length; i++) {
      let el = data[i]
      if (el[0] == "Logic") {
        temp.push([["Type"], [el[1]]])
      }
      if (el[0] == "AlertProperty") {
        temp.push([["Alert Property"], [el[1].slice(30)]])
      }
      if (el[0] == "location") {
        temp.push([["Location"], [el[1]]])
      }
      if (el[0] == "AlertPropertyValueT") {
        temp.push([["Threshold"], [el[1]]])
      }
      if (el[0] == "AlertPropertyValue") {
        temp.push([["Property Value"], [el[1]]])
      }
      if (el[0] == "AlertAck") {
        temp.push([["Acknowledged"], [el[1] ? "Yes" : "No"]])
      }

      if (el[0] == "AlertAckBy" && el[1]) {
        temp.push([["Acknowledged By"], [el[1]]])
      }
      if (el[0] == "Description") {
        let str = el[1]
        str = str.replace("97e3d778-3d13-4177-a4be-62481061b6a6", "Motor_A")
        str = str.replace("ManufacturingSimulator.MotorA.", "")
        el[1] = str
        temp.push([["Alert Message"], [el[1]]])
      }
      if (el[0] == "AlertGenTime") {
        let date = new Date(el[1])
        el[1] = date.toLocaleString()
        temp.push([["Time"], [el[1]]])
      }
    };
    setTableData(temp)
  }, [])
  const [tableData, setTableData] = useState([
    ["Device", "Motor_A"],
    ["AlertProperty", "Acceleration_X"],
    ["Threshold", "320"],
    ["PropertyValue", "350"],
    ["Alert Acknowledged", "No"],
    ["Time", "18 2023 21:15:52"],
    [
      "Alert Message",
      "Accleration X for motor_a has reached above the threshold level. Please reach out to the concerned person",
    ],
  ])


  return (
    <KeyboardAvoidingView
      behavior={Platform.OS == "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS == "ios" ? 0 : 30}
      enabled={Platform.OS === "ios" ? true : false}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <View style={styles.container}>
          <Header
            centerComponent={{
              text: "Alert Details",
              style: { color: "#2e2e38", fontSize: 17 },
            }}
            rightComponent={
              <View style={styles.headerRight}>
                <TouchableOpacity
                  onPress={() => props.handleAlertModal(alertData, "close")}
                >
                  <Icon type="antdesign" name="close" color="red" />
                </TouchableOpacity>
              </View>
            }
            containerStyle={{
              backgroundColor: "white",
              justifyContent: "space-around",
            }}
          />
          <View>
            <Table borderStyle={{ borderWidth: 1.3, borderColor: "##2e2e38" }}>
              <Row
                data={tableHead}
                style={styles.head}
                textStyle={styles.text}
              />
              {tableData.map((el) => {
                return (
                  <Row
                    data={el}
                    style={
                      el[0] != "Alert Message" && el[0] != "Location" ? styles.body : styles.bodyheight
                    }
                    textStyle={styles.bodytext}
                  />
                );
              })}
            </Table>
          </View>

          {!alertData.AlertAck && <Button
            onPress={() => {
              props.handleAlertModal(alertData, "close", "acknowledge");
            }}
            buttonStyle={{
              width: 120,
              padding: 5,
              margin: 30,
              backgroundColor: "#FFE600",
            }}
            title="Acknowledge"
            titleStyle={{ color: "#2e2e38" }}
          />}
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    alignItems: "center",
  },
  cont: { flex: 1, padding: 10, paddingTop: 30, backgroundColor: "#fff" },
  head: {
    width: vw - 40,
    height: 40,
    backgroundColor: "#2e2e38",
  },
  body: {
    width: vw - 40,
    height: 40,
    backgroundColor: "white",
  },
  bodyheight: {
    height: 100,
    backgroundColor: "white",
  },
  text: { textAlign: "center", color: "white" },
  bodytext: {
    display: "flex",
    wordWrap: "break-word",
    margin: 6,
    textAlign: "left",
    color: "black",
  },
  headheight: {
    height: 40,
    backgroundColor: "#2e2e38",
  },
});

export default AlertData;
