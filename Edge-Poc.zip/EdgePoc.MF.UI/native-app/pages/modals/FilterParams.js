import React from 'react';
import { StyleSheet, View } from 'react-native';
import { CheckBox, BottomSheet, Button } from "@rneui/themed";

const FilterParams = props => {
    return (
        <BottomSheet isVisible={true}>
            <View style={[{ flexDirection: "row", justifyContent: "flex-start", backgroundColor: "white" }]}>
                <CheckBox
                    title="Critical"
                />
                <CheckBox
                    title="Warning"
                />
            </View>
            <View
                style={[{
                    flexDirection: "row", backgroundColor: "white", justifyContent: "center",
                    marginBottom: 0,
                    paddingBottom: 10
                }]}
            >
                <Button
                    buttonStyle={{
                        width: 120,
                        padding: 5,
                        marginLeft: 10,
                        backgroundColor: "grey",
                    }}
                    title="Cancel"
                    titleStyle={{ color: "white" }}
                />
                <Button
                    buttonStyle={{
                        width: 120,
                        padding: 5,
                        marginLeft: 10,
                        backgroundColor: "#FFE600",
                    }}
                    title="Submit"
                    titleStyle={{ color: "#2e2e38" }}
                />
            </View>

        </BottomSheet>

    )
}

const styles = StyleSheet.create({

});

export default FilterParams;