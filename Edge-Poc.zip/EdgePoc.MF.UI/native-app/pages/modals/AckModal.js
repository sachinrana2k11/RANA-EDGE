import {
    StyleSheet,
    View,
    TextInput,
    ToastAndroid,
    Platform,
    AlertIOS,
    Keyboard,
    TouchableWithoutFeedback,
    KeyboardAvoidingView,
    Dimensions,
    TouchableOpacity,
} from "react-native";
import { Icon, Header, Button, CheckBox } from "@rneui/themed";
import { useEffect, useState } from "react";
import Loader from "./Loader";
function notify(msg) {
    if (Platform.OS === "android") {
        ToastAndroid.show(msg, ToastAndroid.LONG, ToastAndroid.TOP);
    } else {
        AlertIOS.alert(msg);
    }
}
const vh = Dimensions.get("window").height;
const vw = Dimensions.get("window").width;
const radioData = [
    "Ignore Alert:- Under testing",
    "Ticket raised:- Under maintenance",
    "Resolved:- Asset is running healthy"
]



const AckModal = (props) => {



    const { alertData } = props
    const [msg, setMsg] = useState(radioData[radioData.findIndex(a => a == alertData.AlertAckComment)])
    const setMsgtext = (val) => {
        setMsg(val);
    };
    const greyRadio = alertData.AlertAckComment == radioData[1]
    const [selectedRadio, setSelectedRadio] = useState(radioData.findIndex(a => a == alertData.AlertAckComment))
    const [loading, setLoading] = useState(false)
    const handleRadioSelect = (idx) => {
        if (greyRadio && idx == 0) {
            return
        }
        setSelectedRadio(idx)
        setMsgtext(radioData[idx])
    }
    let ackData = {
        "AlertAckBy": "Kanav",
        "msgid": alertData.msgid ? alertData.msgid : "75d07839-ff83-4a5a-82f3-33eea721c237",
        "AlertProperty": alertData.AlertProperty,
    }
    const ackAlertApi = () => {

        if (alertData.AlertAckComment != msg) {
            setLoading(true)
            ackData.AlertAckComment = msg
            ackData.AlertAckTime = `${Date.now()}`
            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(ackData)
            };
            fetch("http://10.1.45.71:3002/deviceService/v1/alertAck", requestOptions)
                .then((res) => res.json())
                .then((data) => {
                    setLoading(false)
                    props.handleAckModal(data[0], "close", "newData")
                    notify("Alert has been acknowledged")
                }, err => {
                    setLoading(false)
                    notify(err)
                    props.handleAckModal(alertData, "close")
                })

        } else {
            props.handleAckModal(alertData, "close")
        }
    }






    return (
        <KeyboardAvoidingView
            behavior={Platform.OS == "ios" ? "padding" : "height"}
            keyboardVerticalOffset={Platform.OS == "ios" ? 0 : 30}
            enabled={Platform.OS === "ios" ? true : false}
        >
            <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
                <View style={styles.container}>
                    <Loader loading={loading} />
                    <Header
                        centerComponent={{
                            text: "Acknowledge Alert",
                            style: { color: "#2e2e38", fontSize: 17 },
                        }}
                        rightComponent={
                            <View style={styles.headerRight}>
                                <TouchableOpacity
                                    onPress={() => props.handleAckModal(alertData, "close")}
                                >
                                    <Icon type="antdesign" name="close" color="red" />
                                </TouchableOpacity>
                            </View>
                        }
                        containerStyle={{
                            backgroundColor: "white",
                            justifyContent: "space-around",
                        }}
                    />

                    <View>
                        {radioData.map((el, i) => {
                            return (<CheckBox key={i}
                                checked={selectedRadio == i}
                                checkedIcon="dot-circle-o"
                                uncheckedIcon="circle-o"
                                title={el}
                                onPress={() => handleRadioSelect(i)}
                                containerStyle={{ margin: 0, padding: 0 }}
                                textStyle={i == 0 && greyRadio ? { color: "grey" } : {}}
                            />
                            )
                        })}
                        {/* <TextInput
                            style={styles.input}
                            onChangeText={(val) => {
                                setMsgtext(val);
                            }}

                            multiline
                            numberOfLines={5}

                            value={msg}
                            keyboardType="text"
                            placeholder="Enter Comments(optional)"
                        /> */}
                    </View>



                    <View
                        style={[styles.rowStyle, {
                            justifyContent: "flex-end",
                            marginTop: 15,
                            marginRight: 20
                        }]}
                    >
                        <Button
                            onPress={() => props.handleAckModal(alertData, "close")
                            }
                            buttonStyle={{
                                width: 120,
                                padding: 5,
                                marginLeft: 10,
                                backgroundColor: "grey",
                            }}
                            title="Cancel"
                            titleStyle={{ color: "white" }}
                        />
                        <Button
                            onPress={() => {
                                ackAlertApi();
                            }}
                            buttonStyle={{
                                width: 120,
                                padding: 5,
                                marginLeft: 10,
                                backgroundColor: "#FFE600",
                            }}
                            title="Confirm"
                            titleStyle={{ color: "#2e2e38" }}
                        />
                    </View>
                </View>
            </TouchableWithoutFeedback>
        </KeyboardAvoidingView>
    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: "white",
        alignItems: "center",
    },
    cont: { flex: 1, padding: 10, paddingTop: 30, backgroundColor: "#fff" },
    head: {
        width: vw - 40,
        height: 40,
        backgroundColor: "#2e2e38",
    },
    body: {
        width: vw - 40,
        height: 40,
        backgroundColor: "white",
    },
    bodyheight: {
        height: 100,
        backgroundColor: "white",
    },
    text: { textAlign: "center", color: "white" },
    bodytext: {
        display: "flex",
        wordWrap: "break-word",
        margin: 6,
        textAlign: "left",
        color: "black",
    },
    headheight: {
        height: 40,
        backgroundColor: "#2e2e38",
    },
    rowStyle: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 5,
        width: vw - 10,
    },
    input: {
        width: vw - 40,
        padding: 10,
        marginTop: 20,
        marginBottom: 20,
        borderWidth: 1,
        borderColor: "#FFE600",
        borderRadius: 7,
        backgroundColor: "white",
        maxHeight: 300
    },

});

export default AckModal;
