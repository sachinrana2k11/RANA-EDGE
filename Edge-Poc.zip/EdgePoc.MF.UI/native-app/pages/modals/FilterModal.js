import {
  StyleSheet,
  View,
  Text,
  ToastAndroid,
  Platform,
  AlertIOS,
  Keyboard,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
  Dimensions,
  TouchableOpacity, ScrollView
} from "react-native";
import { Icon, Header, Button, Input, CheckBox } from "@rneui/themed";
import DateTimePicker from "@react-native-community/datetimepicker";
import { useState } from "react";


function getFormattedDate(date) {
  let year = date.getFullYear();
  let month = (1 + date.getMonth()).toString().padStart(2, '0');
  let day = date.getDate().toString().padStart(2, '0');
  return month + '/' + day + '/' + year;
}

function notify(msg) {
  if (Platform.OS === "android") {
    ToastAndroid.show(msg, ToastAndroid.LONG, ToastAndroid.TOP);
  } else {
    AlertIOS.alert(msg);
  }
}
const vh = Dimensions.get("window").height;
const vw = Dimensions.get("window").width;

const FilterModal = (props) => {

  let date = new Date()
  let today = getFormattedDate(date)
  const [startDate, setStartDate] = useState(today);
  const [endDate, setEndDate] = useState(today);
  const [startTime, setStartTime] = useState();
  const [endTime, setEndTime] = useState();
  const [boolDate1, setBoolDate1] = useState(false)
  const [boolDate2, setBoolDate2] = useState(false)
  const [boolTime1, setBoolTime1] = useState(false)
  const [boolTime2, setBoolTime2] = useState(false)


  const openDate1 = () => {
    setBoolDate1(true)
  };
  const closeDate1 = (dt) => {
    setBoolDate1(false)
    let date = dt.nativeEvent.timestamp
    setStartDate(getFormattedDate(new Date(date)))
  };
  const openDate2 = () => {
    setBoolDate2(true)
  };
  const closeDate2 = (dt) => {
    setBoolDate2(false)
    let date = dt.nativeEvent.timestamp
    setEndDate(getFormattedDate(new Date(date)))
  };
  const openTime1 = () => {
    setBoolTime1(true)
  };
  const closeTime1 = (dt) => {
    setBoolTime1(false)
    let date = new Date(dt.nativeEvent.timestamp)
    let time = date.toTimeString().slice(0, 8);
    setStartTime(time)
  };
  const openTime2 = () => {
    setBoolTime2(true)
  };
  const closeTime2 = (dt) => {
    setBoolTime2(false)
    let date = new Date(dt.nativeEvent.timestamp)
    let time = date.toTimeString().slice(0, 8);
    setEndTime(time)
  };

  const [checkedCritical, setCheckedCritical] = useState(true);
  const toggleCheckboxCritical = () => setCheckedCritical(!checkedCritical);
  const [checkedWarning, setCheckedWarning] = useState(true);
  const toggleCheckboxWarning = () => setCheckedWarning(!checkedWarning);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS == "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS == "ios" ? 0 : 30}
      enabled={Platform.OS === "ios" ? true : false}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <View style={styles.container}>
          <Header
            centerComponent={{
              text: "Filter Alerts",
              style: { color: "#2e2e38", fontSize: 20 },
            }}
            rightComponent={
              <View style={styles.headerRight}>
                <TouchableOpacity
                  onPress={() => props.handleFilterModal("close")}>
                  <Icon type="antdesign" name="close" color="red" />
                </TouchableOpacity>
              </View>
            }
            containerStyle={{
              backgroundColor: "white",
              justifyContent: "space-around",
              margin: 10,
            }}
          />
          {/* <ScrollView style={styles.scrollView}>
            <View style={[{ justifyContent: "center" }]}>
              {[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1].map(() => {
                return (
                  <Text>10 Min</Text>
                )
              })}
            </View>
          </ScrollView> */}

          <View style={styles.rowStyle}>
            <Text style={{ margin: 2, marginLeft: 20 }}>Start Date</Text>
            <TouchableOpacity onPress={() => openDate1()}>
              <Input
                placeholder="Start Date"
                leftIcon={{ type: "font-awesome", name: "calendar", size: 14 }}
                value={startDate}
                disabled={true}
                containerStyle={{ width: 200 }}
                inputStyle={{ fontSize: 16, textAlign: "center" }}
                inputContainerStyle={{ height: 22 }}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.rowStyle}>
            <Text style={{ margin: 2, marginLeft: 20 }}>End Date</Text>
            <TouchableOpacity onPress={() => openDate2()}>
              <Input
                placeholder="Start Date"
                leftIcon={{ type: "font-awesome", name: "calendar", size: 14 }}
                value={endDate}
                disabled={true}
                containerStyle={{ width: 200 }}
                inputStyle={{ fontSize: 16, textAlign: "center" }}
                inputContainerStyle={{ height: 22 }}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.rowStyle}>
            <Text style={{ margin: 2, marginLeft: 20 }}>Start Time</Text>
            <TouchableOpacity onPress={() => openTime1()}>
              <Input
                placeholder="Start Date"
                leftIcon={{ type: "feather", name: "clock", size: 14 }}
                value={startTime}
                disabled={true}
                containerStyle={{ width: 200 }}
                inputStyle={{ fontSize: 16, textAlign: "center" }}
                inputContainerStyle={{ height: 22 }}
              />
            </TouchableOpacity>
          </View>

          <View style={styles.rowStyle}>
            <Text style={{ margin: 2, marginLeft: 20 }}>End Time</Text>
            <TouchableOpacity onPress={() => openTime2()}>
              <Input
                placeholder="Start Date"
                leftIcon={{ type: "feather", name: "clock", size: 14 }}
                value={endTime}
                disabled={true}
                containerStyle={{ width: 200 }}
                inputStyle={{ fontSize: 16, textAlign: "center" }}
                inputContainerStyle={{ height: 22 }}
              />
            </TouchableOpacity>
          </View>
          <View style={[styles.rowStyle, { marginTop: 0, justifyContent: "center" }]}>
            <CheckBox
              checked={checkedCritical}
              onPress={toggleCheckboxCritical}
              title="Critical"
            />
            <CheckBox
              checked={checkedWarning}
              onPress={toggleCheckboxWarning}
              title="Warning"
            />
          </View>
          <View
            style={[styles.rowStyle, {
              justifyContent: "center",
              marginTop: 15,
            }]}
          >
            <Button
              onPress={() => {
                props.handleFilterModal("close");
              }}
              buttonStyle={{
                width: 120,
                padding: 5,
                marginLeft: 10,
                backgroundColor: "grey",
              }}
              title="Cancel"
              titleStyle={{ color: "white" }}
            />
            <Button
              onPress={() => {
                props.handleFilterModal("close");
              }}
              buttonStyle={{
                width: 120,
                padding: 5,
                marginLeft: 10,
                backgroundColor: "#FFE600",
              }}
              title="Submit"
              titleStyle={{ color: "#2e2e38" }}
            />
          </View>

          {boolDate1 && (<DateTimePicker
            value={new Date()}
            mode={'date'}
            is24Hour={true}
            display="default"
            onChange={(date) => { closeDate1(date) }}
          />)
          }
          {boolDate2 && (<DateTimePicker
            value={new Date()}
            mode={'date'}
            is24Hour={true}
            display="default"
            onChange={(date) => { closeDate2(date) }}
          />)
          }

          {boolTime1 && (<DateTimePicker
            value={new Date()}
            mode={'time'}
            is24Hour={true}
            display="default"
            onChange={(date) => { closeTime1(date) }}
          />)
          }

          {boolTime2 && (<DateTimePicker
            value={new Date()}
            mode={'time'}
            is24Hour={true}
            display="default"
            onChange={(date) => { closeTime2(date) }}
          />)
          }
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView >
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    alignItems: "center",
  },
  rowStyle: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 5,
    width: vw - 10,
  },
  scrollView: { height: 150, width: vw - 50 }
});

export default FilterModal;
