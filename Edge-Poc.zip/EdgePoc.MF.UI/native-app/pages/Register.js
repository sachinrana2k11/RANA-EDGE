import React, { useState, createRef } from "react";
import { useNavigate } from "react-router-native";

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  Image,
  ToastAndroid,
  Platform,
  AlertIOS,
  SafeAreaView,
  Pressable,
  Keyboard,
  TouchableWithoutFeedback,
  Dimensions,
  KeyboardAvoidingView,
} from "react-native";

function notify(msg) {
  if (Platform.OS === "android") {
    ToastAndroid.show(msg, ToastAndroid.LONG, ToastAndroid.TOP);
  } else {
    AlertIOS.alert(msg);
  }
}
const vh = Dimensions.get("window").height;
const vw = Dimensions.get("window").width;

const RegisterScreen = () => {
  const navigate = useNavigate();

  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [confirmPassword, setConfirmPassword] = React.useState("");

  const setEmailtext = (val) => {
    setEmail(val);
  };
  const setNameText = (val) => {
    setName(val);
  };

  const setPasswordtext = (val) => {
    setPassword(val);
  };

  const setConfirmPasswordtext = (val) => {
    setConfirmPassword(val);
  };
  const register = () => {
    if (password && email) {
      notify("User Registered Successfully");
      handlePath("chat");
    } else {
      notify("Please fill all the details ");
    }
  };

  const handlePath = (path) => {
    navigate({
      pathname: `/${path}`,
    });
  };
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS == "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS == "ios" ? 0 : 30}
      enabled={Platform.OS === "ios" ? true : false}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <View style={styles.container}>
          <Image style={styles.eyLogos} source={require("../assets/ey2.png")} />
          <SafeAreaView>
            <Text style={styles.label}>
              Name <Text style={styles.asterisk}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              onChangeText={(val) => {
                setNameText(val);
              }}
              value={name}
              keyboardType="text"
              placeholder="Enter Name"
            />

            <Text style={styles.label}>
              Email <Text style={styles.asterisk}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              onChangeText={(val) => {
                setEmailtext(val);
              }}
              value={email}
              keyboardType="text"
              placeholder="Enter Email"
            />
            <Text style={styles.label}>
              Password <Text style={styles.asterisk}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              onChangeText={(val) => {
                setPasswordtext(val);
              }}
              value={password}
              secureTextEntry={true}
              placeholder="Enter Password"
            />
            <Text style={styles.label}>
              Confirm Password <Text style={styles.asYterisk}>*</Text>
            </Text>
            <TextInput
              style={styles.input}
              onChangeText={(val) => {
                setConfirmPasswordtext(val);
              }}
              value={confirmPassword}
              secureTextEntry={true}
              placeholder="Confirm Password"
            />

            <View style={styles.buttonView}>
              <Pressable style={styles.submit} onPress={register}>
                <Text style={styles.submitText}>Register </Text>
              </Pressable>

              <Text style={styles.label}>
                Already have an account ?
                <Text
                  onPress={() => handlePath("login")}
                  style={styles.signupLink}
                >
                  Login
                </Text>
              </Text>
            </View>
          </SafeAreaView>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#2e2e38",
    alignItems: "center",
    // width: 400,
    // height: vh - 45,
  },
  text: {
    color: "white",
  },
  input: {
    height: 40,
    margin: 12,
    width: 240,
    borderWidth: 1,
    borderColor: "#FFE600",
    padding: 10,
    borderRadius: 7,
    backgroundColor: "white",
  },
  label: {
    color: "white",
    paddingTop: 10,
    marginLeft: 10,
    fontWeight: "500",
  },

  submit: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 10,
    borderRadius: 4,
    elevation: 3,
    width: 120,
    backgroundColor: "#FFE600",
  },
  submitText: {
    fontSize: 16,
    lineHeight: 21,
    fontWeight: "bold",
    letterSpacing: 0.25,
    color: "#2e2e38",
  },
  buttonView: {
    paddingTop: 20,
    alignItems: "center",
  },
  signupLink: {
    color: "#FFE600",
    fontSize: 16,
  },
  asterisk: { color: "red" },
});

export default RegisterScreen;
