import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import LoginScreen from "./pages/Login";
import { Route, Routes, useLocation } from "react-router-native";
import RegisterScreen from "./pages/Register";
import Home from "./pages/Home";
import AlertList from "./pages/AlertList";
import Landing from "./pages/landing";
export default function Index() {
  let location = useLocation();
  let groundColor = "whitesmoke";
  if (
    location.pathname == "/" ||
    location.pathname == "/register" ||
    location.pathname == "/login"
  ) {
    groundColor = "#2e2e38";
  }
  return (
    <SafeAreaProvider>
      <View style={[styles.container, { backgroundColor: groundColor }]}>
        <Routes>
          <Route exact path="/" element={<LoginScreen />} />
          <Route path="/login" element={<LoginScreen />} />
          <Route path="/register" element={<RegisterScreen />} />
          <Route path="/home" element={<Home />} />
          <Route path="/chat" element={<AlertList />} />
          <Route path="/landing" element={<Landing />} />

        </Routes>
        <StatusBar style="auto" />
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#2e2e38",
    alignItems: "center",
    justifyContent: "center",
  },
});

