import pickle

import pandas as pd

from DB.DBService import DBService
import warnings
import time
from CFG.ConfigHandler import ConfigHandler
import os
from LOG.LogsManager import Log


class Main:
    def __init__(self):
        try:
            print("\nHealth Module Initializing " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.LOG = Log()
            self.dbService = DBService()
            self.sync_time = self.configdata['OPC']['sync_time']
            self.wait_time = self.configdata['OPC']['wait_time']
            self.assets = self.configdata['Influx']['Assets']
            self.last_time_temp = []
            for x in range(len(self.assets)):
                self.last_time_temp.append("")
        except Exception as ex:
            print("\nIntialization for Health Module Failed " + str(os.path.basename(__file__)) + str(ex))

    def main(self):
        try:
            print("\nHealth Module Started Running " + str(os.path.basename(__file__)))
            self.LOG.INFO("Health Module Started Running " + str(os.path.basename(__file__)))
            while True:
                output = self.dbService.fetch_latest()
                for ind in output.index:
                    #print(output)
                    asset = output["asset_name"][ind]
                    asset_index = self.assets.index(asset)
                    # print(asset_index)
                    # print(output["_time"][ind])
                    # print(self.last_time_temp[asset_index])
                    if output["_time"][ind] != self.last_time_temp[asset_index]:
                        output1 = self.health_calc(output, ind)
                        if output1 is None:
                            print("ML Health not calculated..will wait for " + str(self.wait_time) + str(
                                os.path.basename(__file__)))
                            self.LOG.WARNING("ML Health not calculated..will wait for " + str(self.wait_time) + str(
                                os.path.basename(__file__)))
                        else:
                            response = self.dbService.write_ml(output1,ind)
                            if response:
                                self.last_time_temp[asset_index] = output["_time"][ind]
                                print(
                                    "Calculated ML Health for " + str(output["_time"][ind]) + str(os.path.basename(__file__)))
                                self.LOG.INFO(
                                    "Calculated ML Health for " + str(output["_time"][ind]) + str(os.path.basename(__file__)))
                            else:
                                print("ML Health not saved..will wait for " + str(self.wait_time) + str(
                                    os.path.basename(__file__)))
                                self.LOG.WARNING("ML Health not saved..will wait for " + str(self.wait_time) + str(
                                    os.path.basename(__file__)))
                    else:
                        print("No new record available for health calc...will check after " + str(self.wait_time) + str(
                            os.path.basename(__file__)))
                        self.LOG.INFO(
                            "No new record available for health calc...will check after " + str(self.wait_time) + str(
                                os.path.basename(__file__)))
                time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nHealth Module Stopped Running " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Health Module Stopped Running " + str(os.path.basename(__file__)) + str(ex))

    def health_calc(self, inp, ind):
        try:
            retput = pd.DataFrame()
            print("\nCalculating ML Output " + str(os.path.basename(__file__)))
            self.LOG.INFO("Calculating ML Output " + str(os.path.basename(__file__)))
            health_x, health_y, health_z, health_index, health_status = [], [], [], [], []

            rms_x = inp[['ManufacturingSimulator.'+inp['asset_name'][ind]+'.rms_velocity_x']]
            rms_y = inp[['ManufacturingSimulator.'+inp['asset_name'][ind]+'.rms_velocity_y']]
            rms_z = inp[['ManufacturingSimulator.'+inp['asset_name'][ind]+'.rms_velocity_z']]
            rms_x.dropna(inplace=True)
            rms_y.dropna(inplace=True)
            rms_z.dropna(inplace=True)
            rms_x.rename(columns={'ManufacturingSimulator.'+inp['asset_name'][ind]+'.rms_velocity_x': 'rms_velocity_y'}, inplace=True)
            rms_y.rename(columns={'ManufacturingSimulator.'+inp['asset_name'][ind]+'.rms_velocity_y': 'rms_velocity_y'}, inplace=True)
            rms_z.rename(columns={'ManufacturingSimulator.'+inp['asset_name'][ind]+'.rms_velocity_z': 'rms_velocity_y'}, inplace=True)

            #load ML model and predict labels
            model = pickle.load(open('Model/model_rms_y.pkl', 'rb'))
            warnings.filterwarnings("ignore")

            label_x = model.predict(rms_x)
            label_y = model.predict(rms_y)
            label_z = model.predict(rms_z)

            for i in range(len(label_x)):
                # calculates health index
                avg = (label_x[i] + label_y[i] + label_z[i]) / 3
                health_index.append(format(avg, ".2f"))
                # calculate health status
                if 0 <= float(health_index[i]) <= 0.5:
                    health_status.append('Asset is Healthy !')
                elif 0.6 <= float(health_index[i]) <= 1.5:
                    health_status.append('Asset working optimally.')
                elif 1.6 <= float(health_index[i]) <= 2.5:
                    health_status.append('Asset working below par.May need maintenance')
                else:
                    health_status.append('Asset is not healthy. Needs maintenance as soon as possible')
                # categorises the health of asset according to labels
                if label_x[i] == 0:
                    health_x.append("Good")
                elif label_x[i] == 1:
                    health_x.append("Satisfactory")
                elif label_x[i] == 2:
                    health_x.append("Unsatisfactory")
                else:
                    health_x.append("Unacceptable")

                if label_y[i] == 0:
                    health_y.append("Good")
                elif label_y[i] == 1:
                    health_y.append("Satisfactory")
                elif label_y[i] == 2:
                    health_y.append("Unsatisfactory")
                else:
                    health_y.append("Unacceptable")

                if label_z[i] == 0:
                    health_z.append("Good")
                elif label_z[i] == 1:
                    health_z.append("Satisfactory")
                elif label_z[i] == 2:
                    health_z.append("Unsatisfactory")
                else:
                    health_z.append("Unacceptable")

            list1 = [0,1,2,3]
            list2 = [ind]
            temp3 = []
            for element in list1:
                if element not in list2:
                    temp3.append(element)
            retput = inp.drop(temp3, axis=0)

            #adding health index and health of the asset to the main dataframe
            retput['Health_x'] = health_x
            retput['Health_y'] = health_y
            retput['Health_z'] = health_z
            retput['Health_Index'] = health_index
            retput['Health_Status'] = health_status
            # print(inp)
            return retput
        except Exception as ex:
            print("\nMl Calculation Failed " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Ml Calculation Failed " + str(os.path.basename(__file__)) + str(ex))
            return None


main = Main()
main.main()
