import influxdb_client
import datetime
from influxdb_client import Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
from CFG.ConfigHandler import ConfigHandler
import os
from LOG.LogsManager import Log


class DBService:
    def __init__(self):
        try:
            self.LOG = Log()
            print("\nInitializing InfluxDB Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing InfluxDB Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.token = self.configdata['Influx']['Influx_db_API_token']
            self.org = self.configdata['Influx']['Influx_org']
            self.bucket = self.configdata['Influx']['Influx_bucket']
            self.url = self.configdata['Influx']['Influx_url']
            self.raw_measure = self.configdata['Influx']['Influx_RawMeasure']
            self.process_measure = self.configdata['Influx']['Influx_ProcessMeasure']
            self.tag = self.configdata['Influx']['Influx_Tag']
            self.influx_payload_id = self.configdata['Influx']['Influx_payload_ID']
            self.batch_size = self.configdata['Influx']['batch_size']
            self.range = self.configdata['Influx']['range']
            self.synced = self.configdata['Influx']['sync_field']
            self.in_ml_tag = self.configdata['Influx']['In_MLHealth_Tag']
            self.client = influxdb_client.InfluxDBClient(url=self.url, token=self.token, org=self.org)
            self.write_api = self.client.write_api(write_options=SYNCHRONOUS)
            self.query_api = self.client.query_api()
        except Exception as ex:
            self.LOG.ERROR("Connection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nConnection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))

    def fetch_latest(self):
        large_stream = {}
        try:
            query = '''
                   from(bucket:\"''' + self.bucket + '''\")
                       |> range(start:''' + str(self.range) + ''')
                       |> filter(fn: (r) => r["_measurement"] ==\"''' + self.raw_measure + '''\")
                       |> filter(fn: (r) => r["DataSource"] ==\"''' + self.tag + '''\")
                       |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
                       |> sort(columns: ["_time"], desc: true)
                       |> group(columns: ["asset_name"])
                       |> drop(columns: ["_start", "_stop"])
                       |> limit(n:''' + str(self.batch_size) + ''')
                   '''
            # print(str(query))
            large_stream = self.query_api.query_data_frame(query)
            #print(str(large_stream))
            return large_stream
        except Exception as ex:
            self.LOG.ERROR(
                "Latest Record Read operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nLatest Record Read operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            return large_stream

    def write_ml(self, input,ind):
        try:
            input = input.drop(['DataSource', '_measurement', '_time', 'result', 'table'], axis=1)
            point = Point(self.process_measure)
            point.tag("Logic", self.in_ml_tag)
            point.field("MLTime", str(input['devicetime'][ind]))
            input = input.drop(['devicetime'], axis=1)
            input = input.fillna(99999)
            for each in input.columns:
                if input[each][ind] != 99999:
                    point.field(each,input[each][ind])
            point.field(self.synced, int(0))
            point.time(datetime.datetime.utcnow(), write_precision=WritePrecision.MS)
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            #print(str(point))
            return True
        except Exception as ex:
            self.LOG.ERROR("ML HealthStatus Write Operation to InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            print("\nML HealthStatus Write Operation to InfluxDB InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            return False
