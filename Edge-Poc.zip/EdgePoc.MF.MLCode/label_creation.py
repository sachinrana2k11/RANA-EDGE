# Cluster 2: good --->0
# Cluster 0: satisfactory ..1
# Cluster 3: unsatisfactory ..2
# Cluster 1: unacceptable ..3
import pandas as pd
from sklearn.metrics import accuracy_score

df= pd.read_csv("C:\\Users\\QT784NF\\OneDrive - EY\\Desktop\\Edge POC\\EdgePOC-master\\dataset.csv")
velo_x = df.rms_velocity_x
velo_y = df.rms_velocity_y
velo_z = df.rms_velocity_z
label_x=[]
label_y=[]
label_z=[]
for i in range (len(velo_x)):
#     avg= (velo_x[i]+velo_y[i]+velo_z[i])/3
    if velo_x[i]<=2.8:
        label_x.append(0)
    elif velo_x[i]>2.8 and velo_x[i]<=7.1:
        label_x.append(1)
    elif velo_x[i]>7.1 and velo_x[i]<=18:
        label_x.append(2)
    else:
        label_x.append(3)

    
    if velo_y[i]<=2.8:
        label_y.append(0)
    elif velo_y[i]>2.8 and velo_y[i]<=7.1:
        label_y.append(1)
    elif velo_y[i]>7.1 and velo_y[i]<=18:
        label_y.append(2)
    else:
        label_y.append(3)



    if velo_z[i]<=2.8:
        label_z.append(0)
    elif velo_z[i]>2.8 and velo_z[i]<=7.1:
        label_z.append(1)
    elif velo_z[i]>7.1 and velo_z[i]<=18:
        label_z.append(2)
    else:
        label_z.append(3)

df['label_x']= label_x
df['label_y']= label_y
df['label_z']= label_z
df= df.drop(["rpm","noise", "average_velocity_x", "average_velocity_y", "average_velocity_z", "Average_Acceleration_x", "Average_Acceleration_y", "Average_Acceleration_z"], axis=1)
df.to_csv("C:\\Users\\QT784NF\\OneDrive - EY\\Desktop\\Edge POC\\EdgePOC-master\\dataset_labels.csv")
print("done")
# accuracy= accuracy_score(label,df.Clusters)
# print(accuracy)
