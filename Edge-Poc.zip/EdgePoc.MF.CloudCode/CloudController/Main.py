import threading
from AZURE.EventService import EventService
from DB.DBService import DbService
from multiprocessing import Queue
import time
from LOG.LogsManager import Log
import os
from CONFIG.CloudConfigHandler import ConfigHandler
from NOTIFICATION.EmailService import EmailService
from AZURE.JsonService import JsonService


class Main:

    def __init__(self):
        try:
            print("\nCloud Controller Initializing " + str(os.path.basename(__file__)))
            self.LOG = Log()
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.sync_time = self.configdata['OPC']['sync_time']
            self.wait_time = self.configdata['OPC']['wait_time']
            self.email_enable = self.configdata['Email']['Email_Enable']
            self.dbService = DbService()
            self.eventService = EventService()
            self.emailService = EmailService()
            self.jsonService = JsonService()
            self.q1 = Queue()
        except Exception as ex:
            print("\nCloud Controller Intialization Failed" + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Cloud Controller Intialization Failed" + str(os.path.basename(__file__)) + str(ex))

    def main(self):
        try:
            print("\nCloud controller started running" + str(os.path.basename(__file__)))
            self.LOG.INFO("Cloud controller started running" + str(os.path.basename(__file__)))
            t1 = threading.Thread(target=self.listen_event, args=(10,))
            t2 = threading.Thread(target=self.get_data_from_event, args=(10, self.q1,))
            t3 = threading.Thread(target=self.send_to_db, args=(10, self.q1,))
            t4 = threading.Thread(target=self.notification_sender, args=(10,))
            t1.start()
            t2.start()
            t3.start()
            t4.start()
            t1.join()
            t2.join()
            t3.join()
            t4.join()
        except Exception as ex:
            print("\nCloud Controller stopped running " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.INFO("Cloud Controller stopped running " + str(os.path.basename(__file__)) + str(ex))

    def listen_event(self, num):
        try:
            print("\nThread 1: Listening to events from IOT Hub " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 1: Listening to events from IOT Hub " + str(os.path.basename(__file__)))
            self.eventService.get_event()
        except Exception as ex:
            print("\nThread 1 Failed: Listening to events from IOT Hub " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 1 Failed: Listening to events from IOT Hub  " + str(os.path.basename(__file__)) + str(ex))

    def get_data_from_event(self, num, q1):
        try:
            print("\nThread 2: Read Event Data from Hub " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 2: Read Event Data from Hub " + str(os.path.basename(__file__)))
            while 1:
                data_from_event = self.eventService.return_event()
                if data_from_event is not None:
                    print("\nPutting data from iothub in Q1 for db write " + str(data_from_event) + str(
                        os.path.basename(__file__)))
                    self.LOG.INFO("\nPutting data from iothub in Q1 for db write " + str(data_from_event) + str(
                        os.path.basename(__file__)))
                    q1.put(data_from_event)
                time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nThread 2 Failed: Read Event Data from Hub " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 2 Failed: Read Event Data from Hub " + str(os.path.basename(__file__)) + str(ex))

    def send_to_db(self, num, q1):
        try:
            print("\nThread 3 : Sync Data with Influxdb " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 3 : Sync Data with Influxdb " + str(os.path.basename(__file__)))
            while 1:
                if not q1.empty():
                    data_to_db = q1.get(block=False)
                    print("\nSyncing data to influx : " + str(data_to_db) + str(os.path.basename(__file__)))
                    self.LOG.INFO("Syncing data to influx : " + str(data_to_db) + str(os.path.basename(__file__)))
                    status = self.dbService.write_to_db(data_to_db)
                    if status:
                        self.LOG.INFO("Synced  to Influxdb " + str(data_to_db) + str(os.path.basename(__file__)))
                        print("\nSynced  to Influxdb " + str(data_to_db) + str(os.path.basename(__file__)))
                    else:
                        q1.put(data_to_db)
                        self.LOG.WARNING("Sync to Influxdb failed " + str(data_to_db) + str(os.path.basename(__file__)))
                        print("\nSync to Influxdb failed " + str(data_to_db) + str(os.path.basename(__file__)))
                time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nThread 3 Failed: Sync Data with Influxdb " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 3 Failed: Sync Data with Influxdb " + str(os.path.basename(__file__)) + str(ex))

    def notification_sender(self, num):
        try:
            print("\nThread 4 : Email Notification " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 4 : Email Notification " + str(os.path.basename(__file__)))
            while 1:
                if self.email_enable == "Enable":
                    data_stream = self.dbService.get_notify_records()
                    if len(data_stream) > 0:
                        for record in data_stream:
                            for record1 in record.records:
                                in_json = self.jsonService.prep_json_processed(record1)
                                status = self.emailService.Send_Email(in_json)
                                if status:
                                    print("\nEmail Notification Sent Successfully " + str(os.path.basename(__file__)))
                                    self.LOG.INFO("\nEmail Notification Sent Successfully " + str(os.path.basename(__file__)))
                                    status1 = self.dbService.update_processed(in_json)
                                    if status1:
                                        print("\nNotification Status updated in influx " + str(os.path.basename(__file__)))
                                        self.LOG.INFO("\nNotification Status updated in influx " + str(os.path.basename(__file__)))
                                    else:
                                        print("\nFailed to Update Notification Status in Influx " + str(os.path.basename(__file__)))
                                        self.LOG.INFO("\nFailed to Update Notification Status in Influx " + str(os.path.basename(__file__)))
                                else:
                                    print("\nFailed to send Email Notification " + str(os.path.basename(__file__)))
                                    self.LOG.WARNING("\nFailed to send Email Notification  " + str(os.path.basename(__file__)))
                else:
                    print("\nEmail Notifications Disabled " + str(os.path.basename(__file__)))
                    self.LOG.INFO("\nEmail Notifications Disabled " + str(os.path.basename(__file__)))
                time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nThread 4 Failed: Email Notification " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 4 Failed: Email Notification " + str(os.path.basename(__file__)) + str(ex))


main = Main()
main.main()
