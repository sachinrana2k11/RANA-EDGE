from CONFIG.CloudConfigHandler import ConfigHandler
import os
from LOG.LogsManager import Log


class JsonService:
    def __init__(self):
        try:
            self.LOG = Log()
            print("\nInitializing Json Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing Json Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.influx_signals = self.configdata['Influx']['Influx_Signals']
        except Exception as ex:
            self.LOG.ERROR("Initialization of Json Service Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nInitialization of Json Service Failed  " + str(os.path.basename(__file__)) + str(ex))

    def prep_json_raw(self, az_json):
        try:
            payload = {}
            for each in az_json.values:
                payload[each] = az_json[each]
            payload = {key: val for key, val in payload.items() if val is not None}
            removed_val = payload.pop('result', 'No Key found')
            removed_val = payload.pop('table', 'No Key found')
            payload["_time"] = str(az_json["_time"])
            return payload
        except Exception as ex:
            self.LOG.ERROR("Json Prepare Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nJson Prepare Failed " + str(os.path.basename(__file__)) + str(ex))
            return {}

    def prep_json_processed(self, az_json):
        try:
            payload = {}
            for each in az_json.values:
                payload[each] = az_json[each]
            payload = {key: val for key, val in payload.items() if val is not None}
            removed_val = payload.pop('result', 'No Key found')
            removed_val = payload.pop('table', 'No Key found')
            payload["_time"] = str(az_json["_time"])
            return payload
        except Exception as ex:
            self.LOG.ERROR("Json Prepare Failed for processed " + str(os.path.basename(__file__)) + str(ex))
            print("\nJson Prepare Failed for processed " + str(os.path.basename(__file__)) + str(ex))
            return {}
