from azure.eventhub import EventHubConsumerClient
from CONFIG.CloudConfigHandler import ConfigHandler
import json
from queue import Queue
from LOG.LogsManager import Log
import os


class EventService:
    def __init__(self):
        try:
            self.LOG = Log()
            self.LOG.ERROR("Initializing Event Service " + str(os.path.basename(__file__)))
            print("\nInitializing Event Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.CONNECTION_STR = self.configdata["Event"]["EVENT_HUB_CONN_STR"]
            self.EVENTHUB_NAME = self.configdata["Event"]["EVENTHUB_NAME"]
            self.eq = Queue()
        except Exception as ex:
            self.LOG.ERROR("Intializing Event Service Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nIntializing Event Service Failed " + str(os.path.basename(__file__)) + str(ex))

    def return_event(self):
        try:
            if not self.eq.empty():
                data_to_ret = self.eq.get()
                return data_to_ret
            return None
        except Exception as ex:
            self.LOG.ERROR("Error while reading event data from queue " + str(os.path.basename(__file__)) + str(ex))
            print("\nError while reading event data from queue " + str(os.path.basename(__file__)) + str(ex))
            return None

    def on_event(self, partition_context, event):
        try:
            print("\nReceived the data from iothub: \"{}\" from the partition with ID: \"{}\"".format(
                event.body_as_str(encoding='UTF-8'), partition_context.partition_id) + str(os.path.basename(__file__)))
            self.LOG.INFO("Received the data from iothub: \"{}\" from the partition with ID: \"{}\"".format(
                event.body_as_str(encoding='UTF-8'), partition_context.partition_id) + str(os.path.basename(__file__)))
            self.eq.put(json.loads(event.body_as_str(encoding='UTF-8')))
        except Exception as ex:
            self.LOG.ERROR("Error on event method " + str(os.path.basename(__file__)) + str(ex))
            print("\nError on event method " + str(os.path.basename(__file__)) + str(ex))

    def on_partition_initialize(self, partition_context):
        try:
            print("\nPartition: {} has been initialized.".format(partition_context.partition_id) + str(os.path.basename(__file__)))
            self.LOG.INFO("Partition: {} has been initialized.".format(partition_context.partition_id) + str(os.path.basename(__file__)))
        except Exception as ex:
            self.LOG.ERROR("Error while intializing partition " + str(os.path.basename(__file__)) + str(ex))
            print("\nError while intializing partition " + str(os.path.basename(__file__)) + str(ex))

    def on_partition_close(self, partition_context, reason):
        try:
            print("\nPartition: {} has been closed, reason for closing: {}.".format(partition_context.partition_id, reason) + str(os.path.basename(__file__)))
            self.LOG.INFO("Partition: {} has been closed, reason for closing: {}.".format(partition_context.partition_id, reason) + str(os.path.basename(__file__)))
        except Exception as ex:
            self.LOG.ERROR("Error while closing partition " + str(os.path.basename(__file__)) + str(ex))
            print("\nError while closing partition " + str(os.path.basename(__file__)) + str(ex))

    def on_error(self, partition_context, error):
        # Put your code here. partition_context can be None in the on_error callback.
        if partition_context:
            print("\nAn exception: {} occurred during receiving from Partition: {}.".format(partition_context.partition_id, error) + str(os.path.basename(__file__)))
            self.LOG.WARNING("An exception: {} occurred during receiving from Partition: {}.".format(partition_context.partition_id,error) + str(os.path.basename(__file__)))
        else:
            print("\nAn exception: {} occurred during the load balance process.".format(error) + str(os.path.basename(__file__)))
            self.LOG.WARNING("An exception: {} occurred during the load balance process.".format(error) + str(os.path.basename(__file__)))

    def get_event(self):
        consumer_client = EventHubConsumerClient.from_connection_string(
            conn_str=self.CONNECTION_STR,
            consumer_group='$Default',
            eventhub_name=self.EVENTHUB_NAME,
        )
        print("\nEvent Listener Started " + str(os.path.basename(__file__)))
        self.LOG.INFO("Event Listener Started " + str(os.path.basename(__file__)))
        try:
            with consumer_client:
                consumer_client.receive(
                    on_event=self.on_event,
                    on_partition_initialize=self.on_partition_initialize,
                    on_partition_close=self.on_partition_close,
                    on_error=self.on_error,
                    starting_position="@latest",  # "-1" is from the beginning of the partition.
                )
        except KeyboardInterrupt:
            print('\nStopped receiving.')
        except Exception as ex:
            print("\nError on Event Consumer Client " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.INFO("Error on Event Consumer Client " + str(os.path.basename(__file__)) + str(ex))


