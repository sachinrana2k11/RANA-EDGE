import os
import influxdb_client
from influxdb_client import Point
from influxdb_client.client.write_api import SYNCHRONOUS
from influxdb_client.domain.write_precision import WritePrecision
from CONFIG.CloudConfigHandler import ConfigHandler
from LOG.LogsManager import Log


class DbService:
    def __init__(self):
        # influxdb connection
        try:
            self.LOG = Log()
            print("\nInitializing InfluxDB Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing InfluxDB Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.token = self.configdata['Influx']['Influx_db_API_token']
            self.url = self.configdata['Influx']['Influx_url']
            self.org = self.configdata['Influx']['Influx_org']
            self.bucket = self.configdata['Influx']['Influx_bucket']
            self.raw_measure = self.configdata['Influx']['Influx_RawMeasure']
            self.process_measure = self.configdata['Influx']['Influx_ProcessMeasure']
            self.tag = self.configdata['Influx']['Influx_Tag']
            self.influx_payload_id = self.configdata['Influx']['Influx_payload_ID']
            self.influx_signals = self.configdata['Influx']['Influx_Signals']
            self.batch_size = self.configdata['Influx']['batch_size']
            self.range = self.configdata['Influx']['range']
            self.in_Warning_tag = self.configdata['Influx']['In_Warning_tag']
            self.in_Critical_tag = self.configdata['Influx']['In_Critical_tag']
            self.client = influxdb_client.InfluxDBClient(url=self.url, token=self.token, org=self.org)
            self.write_api = self.client.write_api(write_options=SYNCHRONOUS)
            self.query_api = self.client.query_api()
        except Exception as ex:
            self.LOG.ERROR("Connection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nConnection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))

    def write_to_db(self, data_to_influx):
        # Write data to db function
        try:
            point = Point(data_to_influx["_measurement"])
            if data_to_influx["_measurement"] == "RawData":
                point.tag("DataSource", data_to_influx["DataSource"])
            else:
                point.tag("Logic", data_to_influx["Logic"])
                if data_to_influx["Logic"] == "Warning" or data_to_influx["Logic"] == "Critical":
                    point.field("Notified", int(0))
            point.time(data_to_influx['_time'], write_precision=WritePrecision.MS)

            removed_val = data_to_influx.pop('Logic', 'No Key found')
            removed_val = data_to_influx.pop('_time', 'No Key found')
            removed_val = data_to_influx.pop('_measurement', 'No Key found')
            removed_val = data_to_influx.pop('DataSource', 'No Key found')
            removed_val = data_to_influx.pop('Synced', 'No Key found')

            for each in data_to_influx:
                point.field(each, data_to_influx[each])

            # print(str(point))
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            return True
        except Exception as ex:
            self.LOG.ERROR("Write Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nWrite Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            return False

    def get_notify_records(self):
        large_stream = {}
        try:
            query = '''
                   from(bucket:\"''' + self.bucket + '''\")
                       |> range(start:''' + str(self.range) + ''')
                       |> filter(fn: (r) => r["_measurement"] ==\"''' + self.process_measure + '''\")
                       |> filter(fn: (r) => r["Logic"] ==\"''' + self.in_Warning_tag + '''\" or r["Logic"] ==\"''' + self.in_Critical_tag + '''\" )
                       |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
                       |> filter(fn: (r) => r["Notified"] == 0)
                       |> sort(columns: ["_time"], desc: true)
                       |> limit(n:''' + str(self.batch_size) + ''')
                       |> drop(columns: ["_start", "_stop"])
                   '''
            # print(str(query))
            large_stream = self.query_api.query(query)
            return large_stream
        except Exception as ex:
            self.LOG.ERROR(
                "Read Records for Notification operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(
                    ex))
            print(
                "\nRead Records for Notification operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(
                    ex))
            return large_stream

    def update_processed(self, db_in_data):
        try:
            point = None
            point = Point(db_in_data["_measurement"])
            point.tag("Logic", db_in_data["Logic"])
            removed_val = db_in_data.pop('Logic', 'No Key found')
            removed_val = db_in_data.pop('_measurement', 'No Key found')
            removed_val = db_in_data.pop('result', 'No Key found')
            removed_val = db_in_data.pop('table', 'No Key found')
            point.time(db_in_data['_time'])
            removed_val = db_in_data.pop('_time', 'No Key found')
            removed_val = db_in_data.pop('Notified', 'No Key found')
            for each in db_in_data:
                point.field(each, db_in_data[each])
            point.field("Notified", int(1))
            #print("Point" + str(point))
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            return True
        except Exception as ex:
            self.LOG.ERROR("Processed Write Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nProcessed Write Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            return False
