import influxdb_client, os, time
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

class influx:
    def __init__(self):
        self.token = "s6_P6kCEx2GO2_vgdV8JbuV0pE9DrF-mCGloCs4GmDvXMB_N3h5LP5E9fOjvNSjT3-F3FU2L1uP0DA2iyjlPog=="
        self.org = "edgepoc"
        self.bucket = "EdgeDB"
        self.url = "http://192.168.29.115:8086/"
        self.client = influxdb_client.InfluxDBClient(url=self.url, token=self.token, org=self.org)
        self.write_api = self.client.write_api(write_options=SYNCHRONOUS)

    def write_to_db(self,in_data):
        point = (Point("kepware").tag("location", "NewDelhi").time(in_data["timestamp"]).\
                 field("deviceid", in_data["deviceid"]).field("orgid", in_data["orgid"]).field("appid", in_data["msgid"]).\
                 field("piSimulator.AgitatorTank.Speed", in_data["data"]["piSimulator.AgitatorTank.Speed"]).\
                 field("piSimulator.AgitatorTank.Vibration", in_data["data"]["piSimulator.AgitatorTank.Vibration"])
                 )
        self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            #time.sleep(1)  # separate points by 1 second

