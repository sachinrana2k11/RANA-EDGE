import time
from azure.communication.email import EmailClient, EmailContent, EmailAddress, EmailMessage, EmailRecipients

def main():
    try:
        connection_string = "endpoint=https://endpoint-email.communication.azure.com/;accesskey=dX/DutuLyMye9zUOXoDd82FwB38zCXL98dcz7t5CaSJHsJkBvWd9hLFbuQQxIre5rmHN75iOMgJz8bKLMC/y5g=="
        client = EmailClient.from_connection_string(connection_string)
        sender = "DoNotReply@b2c28962-a54a-4572-b5a7-d6aa099fa22b.azurecomm.net"
        content = EmailContent(
            subject="!!Alert From Cloud",
            plain_text="temperature is High on Asset ID : 12345",
            html= "<html><h1>!! ALERT</h1></html>",
        )

        recipient = EmailAddress(email="sakshibol17@gmail.com", display_name="Sakshi Bole")

        message = EmailMessage(
            sender=sender,
            content=content,
            recipients=EmailRecipients(to=[recipient])
        )

        response = client.send(message)
        print(response)

    except Exception as ex:
        print(ex)
main()