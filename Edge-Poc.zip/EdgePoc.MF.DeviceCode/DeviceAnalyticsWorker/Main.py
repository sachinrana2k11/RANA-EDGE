import os
from CFG.ConfigHandler import ConfigHandler
from LOGS.LogsManager import Log
from DB.DbService import DbService
from ANALYTICS.AnalyticsService import AnalyticService
import threading
import time


class Main:
    def __init__(self):
        try:
            print("\nDevice Analytics Worker Initializing " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.LOG = Log()
            self.dbService = DbService()
            self.analyticService = AnalyticService()
            self.sync_time = self.configdata['OPC']['sync_time']
            self.wait_time = self.configdata['OPC']['wait_time']
            self.assets = self.configdata['Analytics']['Assets']
            self.last_time_temp = []
            for x in range(len(self.assets)):
                self.last_time_temp.append("")
            self.last_spike = []
            for x in range(len(self.assets)):
                self.last_spike.append("")
        except Exception as ex:
            print("\nIntialization for Device Analytics Worker Failed " + str(os.path.basename(__file__)) + str(ex))

    def main(self):
        try:
            print("\nDevice Analytics Worker Started Running " + str(os.path.basename(__file__)))
            self.LOG.INFO("Device Analytics Worker Started Running " + str(os.path.basename(__file__)))
            t1 = threading.Thread(target=self.running_status, args=(10,))
            t2 = threading.Thread(target=self.identify_spikes, args=(10,))
            t1.start()
            t2.start()
            t1.join()
            t2.join()
        except Exception as ex:
            print("\nDevice Analytics Worker Stopped Running " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.INFO("Device Analytics Worker Stopped Running " + str(os.path.basename(__file__)) + str(ex))

    def running_status(self, num):
        try:
            print("\nThread 1 :Running Status Calc " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 1 : Running Status Calc " + str(os.path.basename(__file__)))
            while 1:
                run_value = None
                data_stream = self.dbService.fetch_latest()  # get latest
                if len(data_stream) > 0:
                    for record in data_stream:
                        for record1 in record.records:
                            in_json = self.dbService.prep_json(record1)
                            asset = in_json["asset_name"]
                            asset_index = self.assets.index(asset)
                            if in_json['devicetime'] != self.last_time_temp[asset_index]:
                                t = in_json['devicetime']
                                run_value = self.analyticService.logic_runstatus(in_json)
                                response = self.dbService.write_to_runstatus(in_json, run_value)
                                if response:
                                    self.last_time_temp[asset_index] = t
                                    #print(str(self.last_time_temp))
                                    print("Calculated Running Status for timestamp" + str(t) + str(os.path.basename(__file__)))
                                    self.LOG.INFO(
                                        "Calculated Running Status for timestamp" + str(t) + str(os.path.basename(__file__)))
                                else:
                                    print("Running Status not calculated..will wait for " + str(self.wait_time) + str(
                                        os.path.basename(__file__)))
                                    self.LOG.WARNING(
                                        "Running Status not calculated..will wait for " + str(self.wait_time) + str(
                                            os.path.basename(__file__)))
                            else:
                                print("No new record available for running status calc...will check after " + str(
                                    self.wait_time) + str(os.path.basename(__file__)))
                                self.LOG.INFO(
                                    "No new record available for running status calc...will check after " + str(
                                        self.wait_time) + str(os.path.basename(__file__)))
                    time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nThread 1 Failed : Running Status Calc " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 1 Failed: Running Status Calc " + str(os.path.basename(__file__)) + str(ex))

    def identify_spikes(self, num):
        try:
            print("\nThread 2 :Spikes Count " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 2 : Spikes Count " + str(os.path.basename(__file__)))
            while 1:
                spike_value = None
                data_stream = self.dbService.fetch_latest()  # get latest
                if len(data_stream) > 0:
                    for record in data_stream:
                        for record1 in record.records:
                            in_json = self.dbService.prep_json(record1)
                            asset = in_json["asset_name"]
                            asset_index = self.assets.index(asset)
                            if in_json['devicetime'] != self.last_spike[asset_index]:
                                t = in_json['devicetime']
                                spike_value = self.analyticService.logic_spike(in_json)
                                response = self.dbService.write_to_spikecount(in_json, spike_value)
                                if response:
                                    self.last_spike[asset_index] = t
                                    # print(str(self.last_time_temp))
                                    print("Calculated Spikes Count for timestamp" + str(t) + str(os.path.basename(__file__)))
                                    self.LOG.INFO("Calculated Spikes Count for timestamp" + str(t) + str(os.path.basename(__file__)))
                                else:
                                    print("Spikes Count not calculated..will wait for " + str(self.wait_time) + str(
                                        os.path.basename(__file__)))
                                    self.LOG.WARNING(
                                        "Spikes Count not calculated..will wait for " + str(self.wait_time) + str(
                                            os.path.basename(__file__)))
                            else:
                                print("No new record available for Spikes Count calc...will check after " + str(
                                    self.wait_time) + str(os.path.basename(__file__)))
                                self.LOG.INFO(
                                    "No new record available for Spikes Count calc...will check after " + str(
                                        self.wait_time) + str(os.path.basename(__file__)))
                    time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nThread 2 Failed : Spikes Count " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 2 Failed: Spikes Count " + str(os.path.basename(__file__)) + str(ex))


main = Main()
main.main()
