from CONFIG.ConfigHandler import ConfigHandler

config_handler = ConfigHandler()

data=config_handler.config_read()
print(data)

config_handler.config_write('Influx_org','EY')
data=config_handler.config_read()
print(data)
