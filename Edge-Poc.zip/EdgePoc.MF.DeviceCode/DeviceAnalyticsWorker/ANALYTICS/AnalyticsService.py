import os
from LOGS.LogsManager import Log
from CFG.ConfigHandler import ConfigHandler


class AnalyticService:
    def __init__(self):
        try:
            self.LOG = Log()
            print("\nInitializing AnalyticService Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing AnalyticService Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.RunningStatusTag = self.configdata['Analytics']['RunningStatusTag']
            self.assets = self.configdata['Analytics']['Assets']
            self.SpikeTag = self.configdata['Analytics']['SpikeTag']
            self.prev_spike_flag = []
            for x in range(len(self.assets)):
                self.prev_spike_flag.append(0)
            self.spike_start = []
            for x in range(len(self.assets)):
                self.spike_start.append(True)
        except Exception as ex:
            self.LOG.ERROR("Intializing to AnalyticService Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nIntializing to AnalyticService Failed " + str(os.path.basename(__file__)) + str(ex))

    def logic_runstatus(self, in_json):
        try:
            asset = in_json["asset_name"]
            runtag = self.RunningStatusTag[asset]
            key = list(runtag.keys())[0]
            value = runtag[key]
            if in_json[key] >= value:
                run_value = 1
            else:
                run_value = 0
            return run_value
        except Exception as ex:
            self.LOG.ERROR("Logic RunStatus Failed" + str(os.path.basename(__file__)) + str(ex))
            print("\nLogic RunStatus Failed " + str(os.path.basename(__file__)) + str(ex))
            return 0

    def logic_spike(self, in_json):
        try:
            spike_value = 0
            asset = in_json["asset_name"]
            asset_index = self.assets.index(asset)
            spiketag = self.SpikeTag[asset]
            key = list(spiketag.keys())[0]
            value = spiketag[key]
            curr_spike_flag = in_json[key]
            result = curr_spike_flag - self.prev_spike_flag[asset_index]
            if result < 0:
                #print(result * (-1))
                if result * (-1) > value and not self.spike_start[asset_index]:
                    spike_value = 1
            else:
                #print(result)
                if result > value and not self.spike_start[asset_index]:
                    spike_value = 1
            self.prev_spike_flag[asset_index] = curr_spike_flag
            self.spike_start[asset_index] = False
            return spike_value
        except Exception as ex:
            self.LOG.ERROR("Logic Spikes Failed" + str(os.path.basename(__file__)) + str(ex))
            print("\nLogic Spikes Failed " + str(os.path.basename(__file__)) + str(ex))
            return 0
