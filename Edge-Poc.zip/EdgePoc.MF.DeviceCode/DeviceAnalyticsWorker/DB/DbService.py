import os
from LOGS.LogsManager import Log
import influxdb_client
from influxdb_client import Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
import datetime
from CFG.ConfigHandler import ConfigHandler


class DbService:
    def __init__(self):
        # influxdb connection
        try:
            self.LOG = Log()
            print("\nInitializing InfluxDB Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing InfluxDB Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.token = self.configdata['Influx']['Influx_db_API_token']
            self.url = self.configdata['Influx']['Influx_url']
            self.org = self.configdata['Influx']['Influx_org']
            self.bucket = self.configdata['Influx']['Influx_bucket']
            self.raw_measure = self.configdata['Influx']['Influx_RawMeasure']
            self.process_measure = self.configdata['Influx']['Influx_ProcessMeasure']
            self.tag = self.configdata['Influx']['Influx_Tag']
            self.batch_size = self.configdata['Influx']['batch_size']
            self.range = self.configdata['Influx']['range']
            self.in_run_status_field = self.configdata['Influx']['In_run_status_field']
            self.in_RunningStatus_tag = self.configdata['Influx']['In_RunningStatus_tag']
            self.in_spike_tag = self.configdata['Influx']['In_spike_tag']
            self.in_spike_field = self.configdata['Influx']['In_spike_field']
            self.synced = self.configdata['Influx']['sync_field']
            self.client = influxdb_client.InfluxDBClient(url=self.url, token=self.token, org=self.org)
            self.write_api = self.client.write_api(write_options=SYNCHRONOUS)
            self.query_api = self.client.query_api()
        except Exception as ex:
            self.LOG.ERROR("Connection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nConnection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))

    def prep_json(self, az_json):
        try:
            payload = {}
            for each in az_json.values:
                payload[each] = az_json[each]
            payload = {key: val for key, val in payload.items() if val is not None}
            removed_val = payload.pop('result', 'No Key found')
            removed_val = payload.pop('table', 'No Key found')
            payload["_time"] = str(az_json["_time"])
            return payload
        except Exception as ex:
            self.LOG.ERROR("Json Prepare Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nJson Prepare Failed " + str(os.path.basename(__file__)) + str(ex))
            return

    def fetch_latest(self):
        large_stream = {}
        try:
            query = '''
                   from(bucket:\"''' + self.bucket + '''\")
                       |> range(start:''' + str(self.range) + ''')
                       |> filter(fn: (r) => r["_measurement"] ==\"''' + self.raw_measure + '''\")
                       |> filter(fn: (r) => r["DataSource"] ==\"''' + self.tag + '''\")
                       |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
                       |> sort(columns: ["_time"], desc: true)
                       |> group(columns: ["asset_name"])
                       |> drop(columns: ["_start", "_stop"])
                       |> limit(n:''' + str(self.batch_size) + ''')
                   '''
            # print(str(query))
            large_stream = self.query_api.query(query)
            return large_stream
        except Exception as ex:
            self.LOG.ERROR(
                "Latest Record Read operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nLatest Record Read operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            return large_stream

    def write_to_runstatus(self, notify_data, run_value):
        try:
            removed_val = notify_data.pop('DataSource', 'No Key found')
            removed_val = notify_data.pop('_measurement', 'No Key found')
            removed_val = notify_data.pop('_time', 'No Key found')
            point = Point(self.process_measure)
            point.tag("Logic", self.in_RunningStatus_tag)
            point.field("RunningTime", str(notify_data['devicetime']))
            removed_val = notify_data.pop('devicetime', 'No Key found')
            for each in notify_data:
                point.field(each, notify_data[each])
            point.field(self.in_run_status_field, int(run_value))
            point.field(self.synced, int(0))
            point.time(datetime.datetime.utcnow(), write_precision=WritePrecision.MS)
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            #print(str(point))
            return True
        except Exception as ex:
            self.LOG.ERROR("Running Status Write Operation to InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            print("\nRunning Status Write Operation to InfluxDB InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            return False

    def write_to_spikecount(self, notify_data, spike_value):
        try:
            removed_val = notify_data.pop('DataSource', 'No Key found')
            removed_val = notify_data.pop('_measurement', 'No Key found')
            removed_val = notify_data.pop('_time', 'No Key found')
            point = Point(self.process_measure)
            point.tag("Logic", self.in_spike_tag)
            point.field("SpikeTime", str(notify_data['devicetime']))
            removed_val = notify_data.pop('devicetime', 'No Key found')
            for each in notify_data:
                point.field(each, notify_data[each])
            point.field(self.in_spike_field, int(spike_value))
            point.field(self.synced, int(0))
            point.time(datetime.datetime.utcnow(), write_precision=WritePrecision.MS)
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            # print(str(point))
            return True
        except Exception as ex:
            self.LOG.ERROR("Spike Write Operation to InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            print("\nSpike Write Operation to InfluxDB InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            return False


