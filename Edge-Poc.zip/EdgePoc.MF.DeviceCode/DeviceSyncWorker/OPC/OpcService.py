import os
import uuid
import requests
from CONFIGS.ConfigHandler import ConfigHandler
from LOGS.LogsManager import Log
from itertools import groupby


class OpcService:
    def __init__(self):
        try:
            self.LOG = Log()
            print("\nInitializing OPC Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("\nInitializing OPC Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            # get data from config file
            self.kepware_server_address = self.configdata['OPC']['OPC_Server']
            self.request = requests
            self.required_data = self.configdata['OPC']['Opc_Required_Tags']
            self.device_id = self.configdata['OPC']['Opc_DeviceId']
            self.org_id = self.configdata['OPC']['Opc_OrgId']
            self.app_id = self.configdata['OPC']['Opc_AppId']
            self.latitude = self.configdata['OPC']['Device_Latitude']
            self.longitude = self.configdata['OPC']['Device_Longitude']
            self.location = self.configdata['OPC']['Device_Location']
        except Exception as ex:
            self.LOG.ERROR("Error in retrieving OPC config data " + str(os.path.basename(__file__)) + str(ex))
            print("\nError in retrieving OPC config data " + str(os.path.basename(__file__)) + str(ex))

    def key_func(self,k):
        return k['asset_name']

    def prep_json(self, opc_json):
        # Prepare json format data
        try:
            output = []
            for each in range(len(opc_json["readResults"])):
                key = opc_json["readResults"][each]["id"]
                split_tags = key.split('.')
                asset_name = split_tags[1]
                value = opc_json["readResults"][each]["v"]
                time = opc_json["readResults"][each]["t"]
                temp_record = {"tag": key,"value": value, "asset_name": asset_name,"time": time}
                output.append(temp_record)

            output = sorted(output, key=self.key_func)

            final_output = []
            for key, value in groupby(output, self.key_func):
                data = {}
                for each in value:
                    k = each['tag']
                    v = each['value']
                    data[k] = v
                    t = each['time']

                payload = {
                    "deviceid": self.device_id,
                    "orgid": self.org_id,
                    "appid": self.app_id,
                    "msgid": str(uuid.uuid4()),
                    "latitude": self.latitude,
                    "longitude": self.longitude,
                    "location": self.location,
                    "asset_name": key,
                    "data": data,
                    "timestamp": t
                }
                final_output.append(payload)

            return final_output
        except Exception as ex:
            self.LOG.ERROR("Error preparing json from OPC data " + str(os.path.basename(__file__)) + str(ex))
            print("\nError preparing json from OPC data  " + str(os.path.basename(__file__)) + str(ex))

    def getdata(self):
        # Connect to Kepware server and get data
        try:
            opcdata = self.request.post(url=self.kepware_server_address, json=self.required_data)
            opcjson = opcdata.json()
            final_data = self.prep_json(opcjson)
            return final_data
        except Exception as ex:
            self.LOG.ERROR("Error in fetching data from OPC " + str(os.path.basename(__file__)) + str(ex))
            print("\nError in fetching data from OPC " + str(os.path.basename(__file__)) + str(ex))
            return None


