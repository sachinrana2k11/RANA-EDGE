import json

from CONFIGS.ConfigHandler import ConfigHandler
import os
from LOGS.LogsManager import Log


class JsonService:
    def __init__(self):
        try:
            self.LOG = Log()
            print("\nInitializing Json Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing Json Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
        except Exception as ex:
            self.LOG.ERROR("Initialization of Json Service Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nInitialization of Json Service Failed  " + str(os.path.basename(__file__)) + str(ex))

    def prep_json_raw(self, az_json):
        try:
            payload = {}
            for each in az_json.values:
                payload[each] = az_json[each]
            payload = {key: val for key,val in payload.items() if val is not None}
            removed_val = payload.pop('result', 'No Key found')
            removed_val = payload.pop('table', 'No Key found')
            payload["_time"] = str(az_json["_time"])
            return payload
        except Exception as ex:
            self.LOG.ERROR("Json Prepare Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nJson Prepare Failed " + str(os.path.basename(__file__)) + str(ex))
            return {}

    def prep_alert_payload(self, az_json):
        try:
            output = []
            for each in az_json["data"]:
                payload = {"measure": "ProcessedData"}
                if az_json["alert_type"][each] == "Warning":
                    payload["logic"] = "Warning"
                elif az_json["alert_type"][each] == "Critical":
                    payload["logic"] = "Critical"
                payload["deviceid"] = str(az_json["deviceid"])
                payload["orgid"] = str(az_json["orgid"])
                payload["appid"] = str(az_json["appid"])
                payload["msgid"] = str(az_json["msgid"])
                payload["latitude"] = str(az_json["latitude"])
                payload["longitude"] = str(az_json["longitude"])
                payload["location"] = str(az_json["location"])
                payload["asset_name"] = str(az_json["asset_name"])
                payload["AlertProperty"] = each
                payload["AlertPropertyValue"] = float(az_json["data"][each])
                payload["AlertPropertyValueT"] = float(az_json["alert_threshold"][each])
                payload["AlertGenTime"] = az_json["timestamp"]
                payload["Description"] = str(az_json["data"][each]) + " >= " + str(az_json["alert_threshold"][each]) +" (Original Property Value >= Alert Limit)"
                payload["AlertAck"] = int(0)
                payload["AlertAckBy"] = ""
                payload["AlertAckTime"] = ""
                payload["AlertAckComment"] = ""
                output.append(payload)
            return output
        except Exception as ex:
            self.LOG.ERROR("Json Prepare Failed for Alert " + str(os.path.basename(__file__)) + str(ex))
            print("\nJson Prepare Failed for Alert " + str(os.path.basename(__file__)) + str(ex))
            return None

    def prep_json_processed(self, az_json):
        try:
            payload = {}
            for each in az_json.values:
                payload[each] = az_json[each]
            payload = {key: val for key, val in payload.items() if val is not None}
            removed_val = payload.pop('result', 'No Key found')
            removed_val = payload.pop('table', 'No Key found')
            payload["_time"] = str(az_json["_time"])
            return payload
        except Exception as ex:
            self.LOG.ERROR("Json Prepare Failed for processed " + str(os.path.basename(__file__)) + str(ex))
            print("\nJson Prepare Failed for processed " + str(os.path.basename(__file__)) + str(ex))
            return None
