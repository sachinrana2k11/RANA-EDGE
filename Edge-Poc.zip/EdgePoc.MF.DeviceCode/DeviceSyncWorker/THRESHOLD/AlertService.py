from CONFIGS.ConfigHandler import ConfigHandler
from LOGS.LogsManager import Log
import os


class AlertService:
    def __init__(self):
        try:
            self.LOG = Log()
            print("\nInitializing Alert Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing Alert Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.warning_data = self.configdata['Threshold']['Warning_HLimits']
            self.critical_data = self.configdata['Threshold']['Critical_HLimits']
            self.delay_time = self.configdata['Threshold']['Delay_Time']
            self.tags = self.configdata['OPC']['Opc_Required_Tags']
            self.assets = self.configdata['Threshold']['Assets']
            self.threshold_Alert_Values = []
            self.alert_bit = []
            self.alert_type = []
            for y in range(len(self.assets)):
                temp_t_values = []
                temp_a_bit = []
                temp_a_type = []
                for x in range(len(self.tags)):
                    temp_t_values.append([])
                    temp_a_bit.append(0)
                    temp_a_type.append("")
                self.threshold_Alert_Values.append(temp_t_values)
                self.alert_bit.append(temp_a_bit)
                self.alert_type.append(temp_a_type)
        except Exception as ex:
            self.LOG.ERROR("AlertService Initialization failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nAlertService Initialization failed " + str(os.path.basename(__file__)) + str(ex))

    def check_threshold(self, data_check):
        try:
            temp_data = data_check["data"]
            asset = data_check["asset_name"]
            asset_index = self.assets.index(asset)
            warning_data = self.warning_data[asset]
            critical_data = self.critical_data[asset]
            alert_data = {}
            alert_type = {}
            alert_threshold = {}
            alert_curr_bit = []
            for y in range(len(self.assets)):
                temp_c_bit = []
                for x in range(len(self.tags)):
                    temp_c_bit.append(0)
                alert_curr_bit.append(temp_c_bit)

            for each in temp_data:
                if each in warning_data.keys() and each in critical_data.keys():
                    if (temp_data[each] >= warning_data[each]) and (temp_data[each] < critical_data[each]):
                        index = self.tags.index(each)
                        print("\nWarning index is .." + str(index))
                        print(self.alert_bit[1][13])
                        self.alert_bit[asset_index][index] = 1
                        alert_curr_bit[asset_index][index] = 1
                        self.threshold_Alert_Values[asset_index][index].extend([temp_data[each]])
                        self.alert_type[asset_index][index] = "Warning"
                    elif (temp_data[each] > warning_data[each]) and (temp_data[each] >= critical_data[each]):
                        index = self.tags.index(each)
                        print("\nCritical index is .." + str(index))
                        self.alert_bit[asset_index][index] = 1
                        alert_curr_bit[asset_index][index] = 1
                        self.threshold_Alert_Values[asset_index][index].extend([temp_data[each]])
                        self.alert_type[asset_index][index] = "Critical"
                else:
                    print("limit value not found for given tag")

            for x in range(len(self.tags)):
                if self.alert_bit[asset_index][x] == 1 and alert_curr_bit[asset_index][x] == 0:
                    self.alert_bit[asset_index][x] = 0
                    print("Its spike not a alert for " + self.tags[x])
                    self.threshold_Alert_Values[asset_index][x] = []
                    self.alert_type[asset_index][x] = ""
                if len(self.threshold_Alert_Values[asset_index][x]) == self.delay_time + 1 and \
                        self.alert_bit[asset_index][x] == 1 and \
                        alert_curr_bit[asset_index][x] == 1:
                    print("Its a Alert for " + self.tags[x])
                    self.alert_bit[asset_index][x] = 0
                    alert_data[str(self.tags[x])] = temp_data[self.tags[x]]
                    alert_type[str(self.tags[x])] = self.alert_type[asset_index][x]
                    alert_threshold[str(self.tags[x])] = warning_data[self.tags[x]]
                    self.alert_type[asset_index][x] = ""

            print("self.threshold_Alert_Values")
            print(self.threshold_Alert_Values)
            print("self.alert_bit")
            print(self.alert_bit)
            print("alert_curr_bit")
            print(alert_curr_bit)
            print("self.alert_type")
            print(self.alert_type)

            data_check["data"] = alert_data
            data_check["alert_type"] = alert_type
            data_check["alert_threshold"] = alert_threshold
            print("\nAlertService Sending back alert data" + str(data_check) + str(os.path.basename(__file__)))
            self.LOG.INFO("AlertService Sending back alert data" + str(data_check) + str(os.path.basename(__file__)))
            return data_check
        except Exception as ex:
            self.LOG.ERROR("AlertService threshold check module failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nAlertService threshold check module failed " + str(os.path.basename(__file__)) + str(ex))
            return None
