from azure.iot.device import IoTHubModuleClient, IoTHubDeviceClient
from CONFIGS.ConfigHandler import ConfigHandler
import json
import os
import socket
from LOGS.LogsManager import Log


class AzService:
    def __init__(self):
        # IOT hub connection
        try:
            self.LOG = Log()
            print("\nInitializing AzureIOT Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing AzureIOT Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.conn_str = self.configdata['Azure']['AzureIotDevice_conn_str']
            self.ping_url = self.configdata['Azure']['ping_url']
            self.ping_port = self.configdata['Azure']['ping_port']
            # The client object is used to interact with your Azure IoT hub.
            #self.device_client = IoTHubDeviceClient.create_from_connection_string(self.conn_str)
            self.device_client = IoTHubModuleClient.create_from_edge_environment()
            # Connect the client.
            self.device_client.connect()
        except Exception as ex:
            self.LOG.ERROR("Connection to Azure IOT Device Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nConnection to Azure IOT Device Failed " + str(os.path.basename(__file__)) + str(ex))

    def write_to_hub(self, az_data):
        # Send message to IOT devices
        try:
            if self.is_connected():
                self.device_client.send_message(json.dumps(az_data))
                return True
            else:
                print("\nNo Internet Connectivity..." + str(os.path.basename(__file__)))
                self.LOG.WARNING("No Internet Connectivity..." + str(os.path.basename(__file__)))
                return False
        except Exception as ex:
            self.LOG.ERROR("Sending Message to Azure IOT Device Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nSending Message to Azure IOT Device Failed " + str(os.path.basename(__file__)) + str(ex))
            return False

    def is_connected(self):
        try:
            socket.create_connection((self.ping_url, self.ping_port))
            return True
        except OSError:
            pass
        return False
