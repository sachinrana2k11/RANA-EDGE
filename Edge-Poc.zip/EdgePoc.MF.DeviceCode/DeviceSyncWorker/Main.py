import threading
import time
from DB.DbService import DbService
from CONFIGS.ConfigHandler import ConfigHandler
from AZURE.AzService import AzService
from OPC.OpcService import OpcService
from NOTIFICATION.EmailService import EmailService
from OPC.JsonService import JsonService
from LOGS.LogsManager import Log
from THRESHOLD.AlertService import AlertService
from multiprocessing import Queue
import os


class Main:
    def __init__(self):
        try:
            print("\nDevice SyncWorker Initializing " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.LOG = Log()
            self.sync_time = self.configdata['OPC']['sync_time']
            self.wait_time = self.configdata['OPC']['wait_time']
            self.email_enable = self.configdata['Email']['Email_Enable']
            self.dbService = DbService()
            self.azService = AzService()
            self.opcService = OpcService()
            self.alertService = AlertService()
            self.emailService = EmailService()
            self.jsonService = JsonService()
            self.q1 = Queue()
            self.q2 = Queue()
        except Exception as ex:
            print("\nIntialization for Device SynWorker Failed " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Intialization for Device SynWorker Failed " + str(os.path.basename(__file__)) + str(ex))

    def main(self):
        try:
            print("\nDevice SyncWorker Started Running " + str(os.path.basename(__file__)))
            self.LOG.INFO("Device SyncWorker Started Running " + str(os.path.basename(__file__)))
            t1 = threading.Thread(target=self.sync_data_cloud, args=(10,))
            t2 = threading.Thread(target=self.opc_data_reader, args=(10, self.q1,))
            t3 = threading.Thread(target=self.threshold_check, args=(10, self.q1, self.q2,))
            t4 = threading.Thread(target=self.notification_sender, args=(10, self.q2,))
            t5 = threading.Thread(target=self.sync_processed_cloud, args=(10,))
            t1.start()
            t2.start()
            t3.start()
            t4.start()
            t5.start()
            t1.join()
            t2.join()
            t3.join()
            t4.join()
            t5.join()
        except Exception as ex:
            print("\nDevice SyncWorker Stopped Running " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.INFO("Device SyncWorker Stopped Running " + str(os.path.basename(__file__)) + str(ex))

    def sync_processed_cloud(self, num):
        try:
            print("\nThread 5 : Sync ProcessedData to Cloud " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 5 : Sync ProcessedData to Cloud " + str(os.path.basename(__file__)))
            while 1:
                data_stream = self.dbService.fetch_from_processed()
                if len(data_stream) > 0:
                    for record in data_stream:
                        for record1 in record.records:
                            print(
                                "\nSyncing ProcessedData with azure: " + str(record1) + str(os.path.basename(__file__)))
                            self.LOG.INFO(
                                "Syncing ProcessedData with azure: " + str(record1) + str(os.path.basename(__file__)))
                            in_json = {}
                            in_json = self.jsonService.prep_json_processed(record1)
                            status = self.azService.write_to_hub(in_json)
                            if status:
                                response = self.dbService.update_record_processed(in_json, str(record1["_time"]))
                                if response:
                                    print("\nProcessedData Synced -: " + str(in_json) + str(os.path.basename(__file__)))
                                    self.LOG.INFO(
                                        "ProcessedData Synced -: " + str(in_json) + str(os.path.basename(__file__)))
                                else:
                                    print("\nProcessedData Sync Failed at DB side -: " + str(in_json) + str(
                                        os.path.basename(__file__)))
                                    self.LOG.ERROR("ProcessedData Sync Failed at DB side-: " + str(in_json) + str(
                                        os.path.basename(__file__)))
                            elif not status:
                                print("\nProcessedData Not Synced Will be synced after some time-:" + str(
                                    self.wait_time) + str(os.path.basename(__file__)))
                                self.LOG.WARNING("ProcessedData Not Synced Will be synced after some time-:" + str(
                                    self.wait_time) + str(os.path.basename(__file__)))
                    time.sleep(int(self.wait_time))
                elif len(data_stream) < 1:
                    print("\nNo New ProcessedData Available for sync Checking after " + str(
                        self.sync_time) + "Sec .." + str(os.path.basename(__file__)))
                    self.LOG.INFO("No New ProcessedData Available for sync Checking after " + str(
                        self.sync_time) + "Sec .." + str(os.path.basename(__file__)))
                    time.sleep(int(self.sync_time))

        except Exception as ex:
            print("\nThread 5 Failed : Sync ProcessedData to Cloud " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 5 Failed: Sync ProcessedData to Cloud " + str(os.path.basename(__file__)) + str(ex))

    def sync_data_cloud(self, num):
        try:
            print("\nThread 1 : Sync Data to Cloud " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 1 : Sync Data to Cloud " + str(os.path.basename(__file__)))
            while 1:
                # Read from influx and sync with iot
                data_stream = self.dbService.fetch_from_db()
                if len(data_stream) > 0:
                    for record in data_stream:
                        for record1 in record.records:
                            print("\nSyncing Data with azure: " + str(record1) + str(os.path.basename(__file__)))
                            self.LOG.INFO("Syncing Data with azure: " + str(record1) + str(os.path.basename(__file__)))
                            in_json = {}
                            in_json = self.jsonService.prep_json_raw(record1)
                            status = self.azService.write_to_hub(in_json)
                            if status:
                                response = self.dbService.update_record(in_json, str(record1["_time"]))
                                if response:
                                    print("\nData Synced -: " + str(in_json) + str(os.path.basename(__file__)))
                                    self.LOG.INFO("Data Synced -: " + str(in_json) + str(os.path.basename(__file__)))
                                else:
                                    print("\nData Sync Failed at DB side -: " + str(in_json) + str(
                                        os.path.basename(__file__)))
                                    self.LOG.ERROR("Data Sync Failed at DB side-: " + str(in_json) + str(
                                        os.path.basename(__file__)))
                            elif not status:
                                print("\nData Not Synced Will be synced after some time-:" + str(self.wait_time) + str(
                                    os.path.basename(__file__)))
                                self.LOG.WARNING(
                                    "Data Not Synced Will be synced after some time-:" + str(self.wait_time) + str(
                                        os.path.basename(__file__)))
                    time.sleep(int(self.wait_time))
                elif len(data_stream) < 1:
                    print("\nNo New Data Available for sync Checking after " + str(self.sync_time) + "Sec .." + str(
                        os.path.basename(__file__)))
                    self.LOG.INFO(
                        "No New Data Available for sync Checking after " + str(self.sync_time) + "Sec .." + str(
                            os.path.basename(__file__)))
                    time.sleep(int(self.sync_time))

        except Exception as ex:
            print("\nThread 1 Failed : Sync Data to Cloud " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 1 Failed: Sync Data to Cloud " + str(os.path.basename(__file__)) + str(ex))

    def opc_data_reader(self, num, q1):
        try:
            print("\nThread 2 : OPC Read and Local DB Write " + str(os.path.basename(__file__)))
            self.LOG.INFO("Thread 2 : OPC Read and Local DB Write " + str(os.path.basename(__file__)))
            while 1:
                data_from_opc = self.opcService.getdata()
                print("\nData from OPC: " + str(data_from_opc) + str(os.path.basename(__file__)))
                self.LOG.INFO("Data from OPC: " + str(data_from_opc) + str(os.path.basename(__file__)))
                if data_from_opc:
                    for each in data_from_opc:
                        response1 = self.dbService.write_to_db(each)
                        if response1:
                            q1.put(each)
                            print("\nPutting data in Q1 from OPC: " + str(os.path.basename(__file__)) + str(each))
                            self.LOG.INFO("Putting data in Q1 from OPC: " + str(os.path.basename(__file__)) + str(each))
                            print("\nData written to DB: " + str(each) + str(os.path.basename(__file__)))
                            self.LOG.INFO("Data written to DB: " + str(each) + str(os.path.basename(__file__)))
                        else:
                            print("\nDB Data Write Failed: " + str(each) + str(os.path.basename(__file__)))
                            self.LOG.ERROR("DB Data Write Failed: " + str(each) + str(os.path.basename(__file__)))
                    time.sleep(int(self.sync_time))
                else:
                    print("\nNo data from OPC...Checking After " + str(self.wait_time) + " secs" + str(
                        os.path.basename(__file__)))
                    self.LOG.WARNING("No data from OPC...Checking After " + str(self.wait_time) + " secs" + str(
                        os.path.basename(__file__)))
                time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nThread 2 Failed: OPC Read and Local DB Write" + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 2 Failed: OPC Read and Local DB Write" + str(os.path.basename(__file__)) + str(ex))

    def threshold_check(self, num, q1, q2):
        try:
            print("\nThread 3 : Threshold Check " + str(os.path.basename(__file__)))
            self.LOG.INFO("\nThread 3 : Threshold Check " + str(os.path.basename(__file__)))
            while 1:
                if not q1.empty():
                    data_to_check = q1.get(block=False)
                    print(
                        "\nGot data from Q1 for threshold check" + str(os.path.basename(__file__)) + str(data_to_check))
                    self.LOG.INFO(
                        "\nGot data from Q1 for threshold check" + str(os.path.basename(__file__)) + str(data_to_check))
                    alertdata = self.alertService.check_threshold(data_to_check)
                    if alertdata:
                        if len(alertdata["data"].keys()) > 0:
                            q2.put(alertdata)
                            print(
                                "\nPutting data in Q2 for Notification" + str(os.path.basename(__file__)) + str(alertdata))
                            self.LOG.INFO(
                                "\nPutting data in Q2 for Notification" + str(os.path.basename(__file__)) + str(alertdata))
                    else:
                        print("\nFailed threshold check " + str(os.path.basename(__file__)) + str(alertdata))
                        self.LOG.INFO("\nFailed threshold check " + str(os.path.basename(__file__)) + str(alertdata))
                        q1.put(data_to_check)

                time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nThread 3 Failed : Threshold Check " + str(os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("\nThread 3 Failed : Threshold Check " + str(os.path.basename(__file__)) + str(ex))

    def notification_sender(self, num, q2):
        try:
            print("\nThread 4: Send Notification and Record Alert in Processed Measurement " + str(
                os.path.basename(__file__)))
            self.LOG.INFO("Thread 4: Send Notification and Record Alert in Processed Measurement " + str(
                os.path.basename(__file__)))
            while 1:
                if not q2.empty():
                    notify_data = q2.get(block=False)
                    print("\nGot data from Q2 for Notification " + str(os.path.basename(__file__)) + str(notify_data))
                    self.LOG.INFO(
                        "\nGot data from Q1 for Notification " + str(os.path.basename(__file__)) + str(notify_data))
                    payload = self.jsonService.prep_alert_payload(notify_data)
                    for each in payload:
                        if self.email_enable == "Enable":
                            self.emailService.Send_Email(each)
                        else:
                            print("\nEmail Notifications Disabled " + str(os.path.basename(__file__)))
                            self.LOG.INFO("\nEmail Notifications Disabled " + str(os.path.basename(__file__)))
                        status = self.dbService.write_to_processed(each)
                        if status:
                            print("\nAlert Data saved to Processed Measurement " + str(os.path.basename(__file__)) + str(
                                notify_data))
                            self.LOG.INFO(
                                "\nAlert Data saved to Processed Measurement " + str(os.path.basename(__file__)) + str(
                                    notify_data))
                        else:
                            print(
                                "\nFailed Alert Data save to Processed Measurement " + str(os.path.basename(__file__)) + str(
                                    notify_data))
                            self.LOG.INFO(
                                "\nFailed Alert Data save to Processed Measurement " + str(os.path.basename(__file__)) + str(
                                    notify_data))
                            q2.put(notify_data)
                time.sleep(int(self.wait_time))
        except Exception as ex:
            print("\nThread 4 Failed : Send Notification and Record Alert in Processed Measurement " + str(
                os.path.basename(__file__)) + str(ex))
            self.LOG.ERROR("Thread 4 Failed: Send Notification and Record Alert in Processed Measurement " + str(
                os.path.basename(__file__)) + str(ex))


main = Main()
main.main()
