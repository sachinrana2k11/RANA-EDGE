from azure.communication.email import EmailClient, EmailContent, EmailAddress, EmailMessage, EmailRecipients
from CONFIGS.ConfigHandler import ConfigHandler
from LOGS.LogsManager import Log
import os


class EmailService:
    def __init__(self):
        try:
            self.LOG = Log()
            print("\nInitializing Notification Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing Notification Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.Email_connection_string = self.configdata['Email']['Email_connection_string']
            self.client = EmailClient.from_connection_string(self.Email_connection_string)
            self.sender = self.configdata['Email']['Email_Sender_Domain']
            self.recipients = self.configdata['Email']['Email_Recipients']
            self.template = "Dear User,<br><br>ReplaceLogic Alert generated at ReplaceAsset, details are as " \
                            "below:<br><br><b>Line:</b> ReplaceLine<br><b>Equipment:</b>" \
                            "ReplaceAsset<br><b>Time:</b> ReplaceTimestamp<br><b>Alert " \
                            "Name:</b>ReplaceAlertProperty<br><b>Alert Triggered Condition:</b> " \
                            "ReplaceDescription<br><b>Message:</b> ReplaceMessage<br><br><br>Thank you, <br><br><br>"\
                            "<i>Note: This is a system generated email, do not reply to this email.</i>"

        except Exception as ex:
            self.LOG.ERROR("Notification ServiceInitialization failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nNotification Service Initialization failed " + str(os.path.basename(__file__)) + str(ex))

    def Send_Email(self, email_data):
        try:
            rec_list = []
            for each in self.recipients:
                rec_list.append(EmailAddress(email=each))

            split = email_data["AlertProperty"].split('.')
            Property = split[2]
            if email_data["logic"] == "Critical":
                msg = "Critical alert generated due to the original property value being more than the alert limit."
            else:
                msg = "Warning alert generated due to the original property value being more than the alert limit."
            Line = ""
            if email_data["asset_name"] == "MotorA":
                Line = "Production Unit I"
            elif email_data["asset_name"] == "Motor_ConveyorBelt":
                Line = "Dispatch Section"
            elif email_data["asset_name"] == "ID_Fan":
                Line = "Combustion"
            elif email_data["asset_name"] == "Oil_Lubrication_Pump":
                Line = "Lubrication Unit"

            email_template = self.template
            email_template = email_template.replace("ReplaceTimestamp", str(email_data["AlertGenTime"]), 1)
            email_template = email_template.replace("ReplaceAlertProperty", str(Property), 1)
            email_template = email_template.replace("ReplaceDescription", str(email_data["Description"]), 1)
            email_template = email_template.replace("ReplaceMessage", str(msg), 1)
            email_template = email_template.replace("ReplaceLine", str(Line), 1)
            email_template = email_template.replace("ReplaceAsset", str(email_data["asset_name"]), 2)
            email_template = email_template.replace("ReplaceLogic", str(email_data["logic"]), 1)

            content = EmailContent(
                subject="EY EDGE POC NOTIFICATION",
                # plain_text="temperature is High on Asset ID : 12345",
                html=email_template,
            )

            message = EmailMessage(
                sender=self.sender,
                content=content,
                recipients=EmailRecipients(to=rec_list)
            )

            response = self.client.send(message)
            print("\nEmail Notification Sent from edge side" + str(response) + str(os.path.basename(__file__)))
            self.LOG.INFO("Email Notification Sent from edge side" + str(response) + str(os.path.basename(__file__)))
            return True
        except Exception as ex:
            self.LOG.ERROR("Error in Email Sender from edge side " + str(os.path.basename(__file__)) + str(ex))
            print("\nError in Email Sender from edge side " + str(os.path.basename(__file__)) + str(ex))
            return False
