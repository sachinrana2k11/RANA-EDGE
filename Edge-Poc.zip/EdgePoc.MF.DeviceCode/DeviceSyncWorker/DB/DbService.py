import datetime
import influxdb_client
from influxdb_client import Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
from CONFIGS.ConfigHandler import ConfigHandler
import os
from LOGS.LogsManager import Log


class DbService:
    def __init__(self):
        # influxdb connection
        try:
            self.LOG = Log()
            print("\nInitializing InfluxDB Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing InfluxDB Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.token = self.configdata['Influx']['Influx_db_API_token']
            self.url = self.configdata['Influx']['Influx_url']
            self.org = self.configdata['Influx']['Influx_org']
            self.bucket = self.configdata['Influx']['Influx_bucket']
            self.raw_measure = self.configdata['Influx']['Influx_RawMeasure']
            self.process_measure = self.configdata['Influx']['Influx_ProcessMeasure']
            self.tag = self.configdata['Influx']['Influx_Tag']
            self.influx_payload_id = self.configdata['Influx']['Influx_payload_ID']
            self.synced = self.configdata['Influx']['sync_field']
            self.batch_size = self.configdata['Influx']['batch_size']
            self.range = self.configdata['Influx']['range']
            self.in_Warning_tag = self.configdata['Influx']['In_Warning_tag']
            self.in_Critical_tag = self.configdata['Influx']['In_Critical_tag']
            self.client = influxdb_client.InfluxDBClient(url=self.url, token=self.token, org=self.org)
            self.write_api = self.client.write_api(write_options=SYNCHRONOUS)
            self.query_api = self.client.query_api()
        except Exception as ex:
            self.LOG.ERROR("Connection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nConnection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))

    def write_to_db(self, db_data):
        # Write data to db function
        try:
            point = Point(self.raw_measure)
            point.tag("DataSource", self.tag)

            for each in self.influx_payload_id:
                point.field(each, db_data[each])

            for each in db_data["data"]:
                point.field(each, float(db_data["data"][each]))

            point.field(self.synced, int(0))
            point.field("devicetime", db_data['timestamp'])
            point.time(datetime.datetime.utcnow(), write_precision=WritePrecision.MS)

            #print(str(point))
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            return True
        except Exception as ex:
            self.LOG.ERROR("Write Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nWrite Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            return False

    def fetch_from_db(self):
        large_stream = {}
        try:
            query = '''
                from(bucket:\"''' + self.bucket + '''\")
                    |> range(start:''' + str(self.range) + ''')
                    |> filter(fn: (r) => r["_measurement"] ==\"''' + self.raw_measure + '''\")
                    |> filter(fn: (r) => r["DataSource"] ==\"''' + self.tag + '''\")
                    |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
                    |> filter(fn: (r) => r["Synced"] == 0)
                    |> sort(columns: ["_time"], desc: true)
                    |> limit(n:''' + str(self.batch_size) + ''')
                    |> drop(columns: ["_start", "_stop"])
                '''
            # print(str(query))
            large_stream = self.query_api.query(query)
            return large_stream
        except Exception as ex:
            self.LOG.ERROR("Read Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nRead Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            return large_stream

    def update_record(self, db_in_data, record1):
        try:
            removed_val = db_in_data.pop('DataSource', 'No Key found')
            removed_val = db_in_data.pop('_measurement', 'No Key found')
            removed_val = db_in_data.pop('_time', 'No Key found')
            point = Point(self.raw_measure)
            point.tag("DataSource", self.tag)
            for each in db_in_data:
                point.field(each, db_in_data[each])
            point.time(str(record1))
            point.field(self.synced, int(1))
            #print(str(point))
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            return True
        except Exception as ex:
            self.LOG.ERROR("Update Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nUpdate Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            return False

    def write_to_processed(self, db_in_data):
        try:
            point = None
            if db_in_data["logic"] == "Warning" or db_in_data["logic"] == "Critical":
                point = Point(db_in_data["measure"])
                if db_in_data["logic"] == "Warning":
                    point.tag("Logic", "Warning")
                elif db_in_data["logic"] == "Critical":
                    point.tag("Logic", "Critical")
                for each1 in self.influx_payload_id:
                    point.field(each1, db_in_data[each1])
                point.field("AlertProperty", db_in_data["AlertProperty"])
                point.field("AlertPropertyValue", float(db_in_data["AlertPropertyValue"]))
                point.field("AlertPropertyValueT", float(db_in_data["AlertPropertyValueT"]))
                point.field("AlertGenTime", db_in_data["AlertGenTime"])
                point.field("Description", db_in_data["Description"])
                point.field("AlertAck", db_in_data["AlertAck"])
                point.field("AlertAckBy", db_in_data["AlertAckBy"])
                point.field("AlertAckTime", db_in_data["AlertAckTime"])
                point.field("AlertAckComment", db_in_data["AlertAckComment"])
                point.field(self.synced, int(0))
                point.time(datetime.datetime.utcnow(), write_precision=WritePrecision.MS)
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            return True
        except Exception as ex:
            self.LOG.ERROR(
                "Write Operation to InfluxDB Process Measurement Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nWrite Operation to InfluxDB InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            return False

    def fetch_from_processed(self):
        large_stream = {}
        try:
            query = '''
                from(bucket:\"''' + self.bucket + '''\")
                    |> range(start:''' + str(self.range) + ''')
                    |> filter(fn: (r) => r["_measurement"] ==\"''' + self.process_measure + '''\")
                    |> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")
                    |> filter(fn: (r) => r["Synced"] == 0)
                    |> sort(columns: ["_time"], desc: true)
                    |> limit(n:''' + str(self.batch_size) + ''')
                    |> drop(columns: ["_start", "_stop"])
                '''
            # print(str(query))
            large_stream = self.query_api.query(query)
            return large_stream
        except Exception as ex:
            self.LOG.ERROR("Read Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nRead Operation to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            return large_stream

    def update_record_processed(self, db_in_data, record1):
        try:
            point = Point(db_in_data["_measurement"])
            point.tag("Logic", db_in_data["Logic"])
            removed_val = db_in_data.pop('Logic', 'No Key found')
            removed_val = db_in_data.pop('_measurement', 'No Key found')
            removed_val = db_in_data.pop('_time', 'No Key found')
            for each in db_in_data:
                point.field(each, db_in_data[each])
            point.time(str(record1))
            point.field(self.synced, int(1))
            #print(str(point))
            self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            return True
        except Exception as ex:
            self.LOG.ERROR("Update Operation to InfluxDB Process Measurement Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nUpdate Operation to InfluxDB InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            return False
