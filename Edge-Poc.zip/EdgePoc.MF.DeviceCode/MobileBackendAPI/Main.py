import json
from DB.DbService import DbService
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
cors = CORS(app, resources={
    r"/*": {
        "origin": "*"
    }
})
my_flask = DbService()


@app.route('/deviceService/v1/alertCount', methods=['GET'])
def alertCount():
    output = {}
    if 'asset' in request.args:
        asset = request.args["asset"]
    else:
        asset = 'All'
    data_stream = my_flask.getAlertCount(asset)
    print("/deviceService/v1/alertCount response: " + str(data_stream))
    return jsonify(data_stream), 200


@app.route('/deviceService/v1/alertList', methods=['GET'])
def alertList():
    output = []
    if 'start' in request.args:
        start = request.args["start"]
    else:
        start = None
    if 'stop' in request.args:
        stop = request.args["stop"]
    else:
        stop = None
    if 'atype' in request.args:
        atype = request.args["atype"]
    else:
        atype = 'All'
    if 'asset' in request.args:
        asset = request.args["asset"]
    else:
        asset = 'All'
    data_stream = my_flask.getAlertList(start, stop, atype, asset)
    if len(data_stream) > 0:
        for record in data_stream:
            for record1 in record.records:
                row = my_flask.prepAlertList(record1)
                output.append(row)
    print("/deviceService/v1/alertList :" + str(output))
    return jsonify(output), 200


@app.route('/deviceService/v1/alertAck', methods=['POST'])
def alertAck():
    data = json.loads(request.data)
    status = my_flask.updateAlertAck(data)
    print("/deviceService/v1/alertAck :" + str(status))
    return jsonify(status), 200


@app.route('/deviceService/v1/index', methods=['GET'])
def index():
    output = {}
    output = my_flask.getIndexInfo()
    print("/deviceService/v1/index response: " + str(output))
    return jsonify(output), 200


@app.route('/auth', methods=['GET'])
def authRouteHandler():
    if request.authorization["username"] == "admin" and request.authorization["password"] == "Password@123a":
        return "Authorized", 200
    else:
        return "Unauthorized", 401


if __name__ == '__main__':
    app.run(debug=False, host="0.0.0.0", port=3002)
