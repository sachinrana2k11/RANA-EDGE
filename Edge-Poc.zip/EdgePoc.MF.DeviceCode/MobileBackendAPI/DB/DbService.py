import os
from LOGS.LogsManager import Log
import influxdb_client
from influxdb_client import Point
from influxdb_client.client.write_api import SYNCHRONOUS
from CFG.ConfigHandler import ConfigHandler


class DbService:
    def __init__(self):
        # influxdb connection
        try:
            self.LOG = Log()
            print("\nInitializing InfluxDB Service " + str(os.path.basename(__file__)))
            self.LOG.INFO("Initializing InfluxDB Service " + str(os.path.basename(__file__)))
            config_handler = ConfigHandler()
            self.configdata = config_handler.config_read()
            self.token = self.configdata['Influx']['Influx_db_API_token']
            self.url = self.configdata['Influx']['Influx_url']
            self.org = self.configdata['Influx']['Influx_org']
            self.bucket = self.configdata['Influx']['Influx_bucket']
            self.batch_size = self.configdata['Influx']['batch_size']
            self.range = self.configdata['Influx']['range']
            self.process_measure = self.configdata['Influx']['Influx_ProcessMeasure']
            self.raw_measure = self.configdata['Influx']['Influx_RawMeasure']
            self.client = influxdb_client.InfluxDBClient(url=self.url, token=self.token, org=self.org)
            self.write_api = self.client.write_api(write_options=SYNCHRONOUS)
            self.query_api = self.client.query_api()
        except Exception as ex:
            self.LOG.ERROR("Connection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nConnection to InfluxDB Failed " + str(os.path.basename(__file__)) + str(ex))

    def getIndexInfo(self):
        output = {}
        onboard_stream = {}
        active_stream = {}
        offline_stream = {}
        alert_stream = {}
        try:
            onboard_query = '''
                            from(bucket: \"''' + self.bucket + '''\")
                                |> range(start: ''' + str(self.range) + ''')
                                |> filter(fn: (r) => r["_measurement"] ==\"''' + self.raw_measure + '''\")
                                |> filter(fn: (r) => r["DataSource"] == "Kepware")
                                |> filter(fn: (r) => r["_field"] == "asset_name")
                                |> unique()
                                |> count()
                            '''
            print("\n Querying for Onboard Asset\n")
            print(str(onboard_query))
            onboard_stream = self.query_api.query(onboard_query)
            if len(onboard_stream) > 0:
                for record in onboard_stream:
                    for record1 in record.records:
                        output["onboardedAsset"] = record1["_value"]

            active_query = '''
                            from(bucket: \"''' + self.bucket + '''\")
                                  |> range(start:''' + str(self.range) + ''')
                                  |> filter(fn: (r) => r["_measurement"] == \"''' + self.process_measure + '''\")
                                  |> filter(fn: (r) => r["Logic"] == "RunStatus")
                                  |> filter(fn: (r) => r["_field"] == "asset_name" or r["_field"] == "RunningStatus")
                                  |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
                                  |> group(columns: ["host", "asset_name"], mode:"by")  
                                  |> sort(columns: ["_time"], desc: true)
                                  |>limit(n:1)
                                  |>group()
                                  |> filter(fn: (r) => r["RunningStatus"] == 1 )
                                  |>count(column:"asset_name")
                            '''
            print("\n Querying for Active Assets\n")
            print(str(active_query))
            active_stream = self.query_api.query(active_query)
            if len(active_stream) > 0:
                for record in active_stream:
                    for record1 in record.records:
                        output["activeAsset"] = record1["asset_name"]

            offline_query = '''
                            from(bucket: \"''' + self.bucket + '''\")
                                  |> range(start:''' + str(self.range) + ''')
                                  |> filter(fn: (r) => r["_measurement"] == \"''' + self.process_measure + '''\")
                                  |> filter(fn: (r) => r["Logic"] == "RunStatus")
                                  |> filter(fn: (r) => r["_field"] == "asset_name" or r["_field"] == "RunningStatus")
                                  |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
                                  |> group(columns: ["host", "asset_name"], mode:"by")  
                                  |> sort(columns: ["_time"], desc: true)
                                  |>limit(n:1)
                                  |>group()
                                  |> filter(fn: (r) => r["RunningStatus"] == 0 )
                                  |>count(column:"asset_name")
                            '''
            print("\n Querying for Offline Assets\n")
            print(str(offline_query))
            offline_stream = self.query_api.query(offline_query)
            if len(offline_stream) > 0:
                for record in offline_stream:
                    for record1 in record.records:
                        output["offlineAsset"] = record1["asset_name"]

            alert_query = '''
                             from(bucket:\"''' + self.bucket + '''\")
                                   |> range(start:''' + str(self.range) + ''')
                                   |> filter(fn: (r) => r["_measurement"] ==\"''' + self.process_measure + '''\")
                                   |> filter(fn: (r) => r["_field"] =="AlertPropertyValue")
                                   |> count() 
                                   |> drop(columns: ["_start", "_stop","_field","_measurement"])
                            '''
            print("\n Querying for Alert Count Index\n")
            print(str(alert_query))
            alert_stream = self.query_api.query(alert_query)
            if len(alert_stream) > 0:
                for record in alert_stream:
                    for record1 in record.records:
                        output[record1['Logic']] = record1["_value"]
            output['totalCriticalAlerts'] = output.pop('Critical')
            output['totalWarningAlerts'] = output.pop('Warning')
            return output
        except Exception as ex:
            self.LOG.ERROR("Index Info Read operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nIndex Info Read operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            return {}

    def getAlertCount(self, asset):
        data_stream = {}
        output = {}
        res = []
        try:
            if asset == 'All':
                query = '''
                        import "join"
                        left = from (bucket: \"''' + self.bucket + '''\")
                            |> range(start: ''' + str(self.range) + ''')
                            |> filter(fn: (r) => r["_measurement"] == \"''' + self.process_measure + '''\")
                            |> filter(fn: (r) => r["Logic"] == "Warning" )
                            |> filter(fn: (r) => r["_field"] == "asset_name" )
                            |> group(columns: ["host", "_value"], mode: "by")
                            |> count(column: "Logic")
                        right = from (bucket: \"''' + self.bucket + '''\")
                            |> range(start: ''' + str(self.range) + ''')
                            |> filter(fn: (r) => r["_measurement"] == \"''' + self.process_measure + '''\")
                            |> filter(fn: (r) => r["Logic"] == "Critical" )
                            |> filter(fn: (r) => r["_field"] == "asset_name" )
                            |> group(columns: ["host", "_value"], mode: "by")
                            |> count(column: "Logic")
                        join.inner(
                            left: left,
                            right: right,
                            on: (l, r) => l._value == r._value,
                            as: (l, r) => ({l with Critical: r.Logic}),
                        )
                        |> group()
                        '''
                print("\n Querying for AlertCount for all asset\n")
                print(str(query))
                data_stream = self.query_api.query(query)
                if len(data_stream) > 0:
                    for record in data_stream:
                        for record1 in record.records:
                            output = {"Critical": record1["Critical"], "Warning": record1["Logic"],"AssetName": record1["_value"]}
                            res.append(output)
            else:
                query = '''
                       from(bucket:\"''' + self.bucket + '''\")
                           |> range(start:''' + str(self.range) + ''')
                           |> filter(fn: (r) => r["_measurement"] ==\"''' + self.process_measure + '''\")
                           |> filter(fn: (r) => (r["Logic"] == "Critical" or r["Logic"] == "Warning") and r["_field"] == "AlertProperty" )
                           |> filter(fn: (r) => r["_value"] =~/''' + asset + '''/)
                           |> count()  
                       '''
                print("\n Querying for AlertCount for given asset\n")
                print(str(query))
                data_stream = self.query_api.query(query)
                if len(data_stream) > 0:
                    for record in data_stream:
                        for record1 in record.records:
                            output[record1['Logic']] = record1["_value"]
                output["AssetName"] = asset
                res = [output]
            return res
        except Exception as ex:
            self.LOG.ERROR("Alert Count Read operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nAlert Count Read operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            return {}

    def getAlertList(self, start, stop, atype, asset):
        large_stream = {}
        filter_a = None
        range_a = None
        filter_b = None
        try:
            if atype == "All":
                filter_a = "|> filter(fn: (r) => r[\"Logic\"] == \"Critical\" or r[\"Logic\"] == \"Warning\")"
            else:
                filter_a = '''|> filter(fn: (r) => r[\"Logic\"] == \"''' + str(atype) + '''\")'''

            if start and stop:
                range_a = '''|> range(start:''' + str(start) + ''', stop:''' + str(stop) + ''')'''
            else:
                range_a = "|> range(start:-30d)"

            if asset == "All":
                filter_b = ""
            else:
                filter_b = '''|> filter(fn: (r) => r["asset_name"] == \"''' + asset + '''\")'''

            query = '''
                    from(bucket:\"''' + self.bucket + '''\")
                        ''' + range_a + '''
                        |> filter(fn: (r) => r["_measurement"] ==\"''' + self.process_measure + '''\")
                        ''' + filter_a + '''
                        |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value") 
                        ''' + filter_b + '''
                        |> sort(columns: ["_time"], desc: true)
                   '''
            print("\n Querying for AlertList\n")
            print(str(query))
            large_stream = self.query_api.query(query)
            return large_stream
        except Exception as ex:
            self.LOG.ERROR("Alert List operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nAlert List operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            return large_stream

    def prepAlertList(self, az_json):
        try:
            payload = {}
            for each in az_json.values:
                payload[each] = az_json[each]
            return payload
        except Exception as ex:
            self.LOG.ERROR("Prep Alert List Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nPrep Alert List Failed " + str(os.path.basename(__file__)) + str(ex))
            return None

    def update_alert_record(self, db_data, record1, data):
        try:
            db_data["AlertAckBy"] = data["AlertAckBy"]
            db_data["AlertAckComment"] = data["AlertAckComment"]
            db_data["AlertAckTime"] = data["AlertAckTime"]
            db_in_data = db_data.copy()
            point = Point(db_in_data["_measurement"])
            point.tag("Logic", db_in_data["Logic"])
            removed_val = db_in_data.pop('Logic', 'No Key found')
            removed_val = db_in_data.pop('_measurement', 'No Key found')
            removed_val = db_in_data.pop('result', 'No Key found')
            removed_val = db_in_data.pop('table', 'No Key found')
            removed_val = db_in_data.pop('_start', 'No Key found')
            removed_val = db_in_data.pop('_stop', 'No Key found')
            removed_val = db_in_data.pop('_time', 'No Key found')
            removed_val = db_in_data.pop('AlertAck', 'No Key found')
            removed_val = db_in_data.pop('Synced', 'No Key found')
            for each in db_in_data:
                point.field(each, db_in_data[each])
            point.time(str(record1))
            point.field("Synced", int(0))
            point.field("AlertAck", int(1))
            point.time(str(record1))
            print("\n Updating for AlertAck\n")
            #print(str(point))
            #print(str(db_data))
            db_data["Synced"] = int(0)
            db_data["AlertAck"] = int(1)
            #self.write_api.write(bucket=self.bucket, org=self.org, record=point)
            return db_data
        except Exception as ex:
            self.LOG.ERROR(
                "Update Operation to InfluxDB Process Measurement Failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nUpdate Operation to InfluxDB InfluxDB Process Measurement Failed " + str(
                os.path.basename(__file__)) + str(ex))
            return None

    def updateAlertAck(self, data):
        large_stream = {}
        try:
            query = '''
                   from(bucket:\"''' + self.bucket + '''\")
                       |> range(start:''' + str(self.range) + ''')
                       |> filter(fn: (r) => r["_measurement"] ==\"''' + self.process_measure + '''\")
                       |> filter(fn: (r) => r["Logic"] == "Critical" or r["Logic"] == "Warning")
                       |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
                       |> filter(fn: (r) => r["msgid"] == \"''' + str(
                data["msgid"]) + '''\" and r["AlertProperty"] == \"''' + str(data["AlertProperty"]) + '''\")
                   '''
            print("Querying to find update message")
            print(str(query))
            large_stream = self.query_api.query(query)
            if len(large_stream) > 0:
                for record in large_stream:
                    response = None
                    if len(record.records) == 1:
                        for record1 in record.records:
                            in_json = self.prepAlertList(record1)
                            response = self.update_alert_record(in_json, str(record1["_time"]), data)
                    else:
                        self.LOG.WARNING("Found more than one record " + str(os.path.basename(__file__)))
                        print("\nFound more than one record " + str(os.path.basename(__file__)))
                        response = None
                    return response
            else:
                self.LOG.WARNING("No Record found for update " + str(os.path.basename(__file__)))
                print("\nNo Record found for update " + str(os.path.basename(__file__)))
                return None
        except Exception as ex:
            self.LOG.ERROR("Alert Ack operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            print("\nAlert Ack operation in influxdb failed " + str(os.path.basename(__file__)) + str(ex))
            return None
